import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CreatePlaylist extends JFrame
                  implements ActionListener
{
        //the creation of a new file chooser
        //(http://java.sun.com/docs/books/tutorial/uiswing/components/filechooser.html)
        JFileChooser fchooser = new JFileChooser();
        //the buffered reader and file writer.
        private BufferedReader inFile;
        private FileWriter outFile;

        //create an instance of the library data class.
        LibraryData db = new LibraryData();

        //creates a new text field called trackNo.
		JTextField trackNo = new JTextField(2);

		//creates a new text area called playlist.
		JTextArea playlist = new JTextArea(28, 50);

		//creates new buttons which have certain text on them
        //such as "Add to Internal Playlist" and "Open External Playlist".
		JButton add = new JButton("Add to Internal Playlist");
		JButton save = new JButton("Save to External Playlist");
        JButton open = new JButton("Open External Playlist");
		JButton play = new JButton("Play");
		JButton reset = new JButton("Reset");
		//creates new label which indicates that the user should enter the track number ..
		//in the text field provided.
		JLabel enterTrack = new JLabel("Enter the Track Number:");

    public CreatePlaylist()
    {
        setLayout(new BorderLayout());
		setBounds(100, 100, 570, 600);
        setTitle("Create Playlist");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //this is the code for the top JPanel and all of its contents.
		JPanel top = new JPanel();
		top.add(enterTrack);
		enterTrack.setForeground(Color.ORANGE);
		top.add(trackNo);
        top.setBackground(Color.BLACK);
		add("North", top);
		
		//this is the code for the middle JPanel and all of its contents.
		JPanel middle = new JPanel();
		middle.setBackground(Color.BLACK);
        middle.add(add);
		add.setBackground(Color.BLACK);
		add.setForeground(Color.ORANGE);
		add.addActionListener(this);
		middle.add(save);
		save.setBackground(Color.BLACK);
		save.setForeground(Color.ORANGE);
		save.addActionListener(this);
        middle.add(open);
        open.setBackground(Color.BLACK);
		open.setForeground(Color.ORANGE);
		open.addActionListener(this);
		middle.add(play);
		play.setBackground(Color.BLACK);
		play.setForeground(Color.ORANGE);
		play.addActionListener(this);
        middle.setBackground(Color.BLACK);
		middle.add(reset);
		reset.setBackground(Color.BLACK);
		reset.setForeground(Color.ORANGE);
		reset.addActionListener(this);
		add("Center", middle);
        
		//this is the code for the bottom JPanel and all of its contents.
		JPanel bottom = new JPanel();
		bottom.add(playlist);
		bottom.setBackground(Color.ORANGE);
		add("South", bottom);

		//allows the JFrame to be seen, but doesn't allow it to be resized.
		setResizable(false);
		setVisible(true);
    }

    
	public void actionPerformed(ActionEvent e)
    {
      
        if (e.getSource() == add) {
            //new string variables used to get the track number from the text field and the other data ..
			//from the methods in the LibraryData class.
            String key = trackNo.getText();
            String name = LibraryData.getName(key);
            String artist = LibraryData.getArtist(key);
            int rating = LibraryData.getRating(key);
            int playCount = LibraryData.getPlayCount(key);
			
			
			//adds the song details to the playlist based on which track number was entered ..
			//meaning if track number 1 was entered, then the song details under track number one
			//in the library's data will be displayed.
            playlist.append("Name: " + LibraryData.getName(key));
            playlist.append(" ~~ Artist: " + LibraryData.getArtist(key));
            playlist.append(" ~~ Rating: " + stars(LibraryData.getRating(key)));
            playlist.append(" ~~ Play count: " + LibraryData.getPlayCount(key));
			playlist.append("\n \n");

		//this "try and catch" is used as validation to prevent the user from entering text ..
		//into the text field. If the user enters anything else aside from a number, a message will ..
		//appear asking the user to enter a number.
		  try { 
				String numStr = trackNo.getText();
				int num = Integer.parseInt (numStr); 
			} 
			
			catch (NumberFormatException exception) { 
				JOptionPane.showMessageDialog(this, "Please enter a number for the Track Number!");
				playlist.setText("");
			} 
		}

		if (e.getSource() == save) {
			 fchooser.showSaveDialog(this);
           File file = fchooser.getSelectedFile();
            try {
                //when the save button is clicked the displayed text of the internal playlist is written ..
                //to a file, which is named by the user as well as the location it's saved to. 
                outFile = new FileWriter(file + ".txt");
                //the text that's written to the file is taken from the text ..
                //area (called inputTextArea).
                outFile.write(playlist.getText());
                outFile.close();
            }
            
            catch (IOException exception) {
                JOptionPane.showMessageDialog(this, "File not found!");
            }
		}

        if (e.getSource() == open) {

                fchooser.showOpenDialog(this);
                File file = fchooser.getSelectedFile();
                try {
                inFile = new BufferedReader(new FileReader(file + ".txt"));
                playlist.setText(""); // clear the input area
                String line;
                    //each line of the file is read.
                while ((line = inFile.readLine()) != null) {
                //each line of the file that's loaded is displayed.
                //to prevent the text in the text file from all being ..
                //displayed on the same line the "\n" is used to create a ..
                //line break between each line.
                playlist.append(line + "\n");
                }
                inFile.close();
            }

             catch (IOException exception) {
                JOptionPane.showMessageDialog(this, "File not found!");
             }

             //used to catch the exception when opening the playlist, the actual
             //exception occurs when the cancel button is pressed.
			 //(it's more of a notification than an actual exception).
             catch (Exception ex) {
                 JOptionPane.showMessageDialog(this, "You have pressed cancel!");
             }
        }

        if (e.getSource() == play) {
			//sets the variable "key" as the track number entered into the ..
			//text field called "trackNo".
			String key = trackNo.getText();
			//the variable "playCount" gets the song's play count by using the method getPlayCount ..
			//making use of the track number (the key variable declared above).
			int playCount = LibraryData.getPlayCount(key);
			//calls the incrementPlayCount method from the LibraryData class.
			LibraryData.incrementPlayCount(key, playCount);
			
			playlist.setText("Now Playing ..\n\n");

			playlist.append("Song: " + LibraryData.getName(key) + "\n");
            playlist.append("By: " + LibraryData.getArtist(key) + "\n");
			playlist.append("Play Count: " + LibraryData.getPlayCount(key));
			  
			  try { 
				String numStr = trackNo.getText();
				int num = Integer.parseInt (numStr); 
			} 
			
			catch (NumberFormatException exception) { 
				JOptionPane.showMessageDialog(this, "Please enter a number for the Track Number!");
				playlist.setText("");
			} 
        }
       

        if (e.getSource() == reset) {
            //when the reset button is clicked on, both the text field called "trackNo" and the text area ..
			//called "playlist" both remove the text they have entered into them.
			trackNo.setText("");
            playlist.setText("");
        }
    }

      private String stars(int rating) {
        String stars = "";
        for (int i = 0; i < rating; ++i) {
			stars += "*";
        }
        return stars;
    }
}