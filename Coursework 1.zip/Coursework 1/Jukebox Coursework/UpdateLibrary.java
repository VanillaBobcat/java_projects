import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
public class UpdateLibrary extends JFrame
                  implements ActionListener
{

        LibraryData db = new LibraryData();

	//this is the text field where the Track Number is entered.
	JTextField trackNo = new JTextField(2);
	//this is the text area where certain information in shown, depending on ..
	//what you click on.
	JTextArea libraryUpdate = new JTextArea(16, 50);
	//this is the text field where the Rating is entered.
	JTextField ratingEntry = new JTextField(1);
	//this button is used to make updates to the library.
	JButton update = new JButton("Update Library");
    //this button is used to display the library.
    JButton display = new JButton("Display Library");
    //this button is used to unselect the radio buttons.
	JButton clear = new JButton("Unselect Radio Buttons");
	//the buttons created below are radio buttons, there are three which are used to ..
	//sort, artist and reverse the songs in the library. 
    JRadioButton sort = new JRadioButton("Sort");
	JRadioButton song = new JRadioButton("Sort All Songs");
    JRadioButton artist = new JRadioButton("Sort All Artists");
    JRadioButton reverse = new JRadioButton("Reverse");
	//creation of the button group called "ssar", this button group ..
	//contains the sort, artist and reverse radio buttons and only allows ..
	//one of them to be selected at a time.
    ButtonGroup ssar = new ButtonGroup();
	//these are JLabels and they are used to label certain objects on the UpdateLibrary screen.
	JLabel enterTrack  = new JLabel("Enter a Track Number:");
	JLabel enterRating = new JLabel("Enter a New Rating (1-5):");
	
	
    public static void main(String[] args)


    {
        UpdateLibrary jf = new UpdateLibrary();
    }
    
    public UpdateLibrary()
    {
        setLayout(new BorderLayout());
		setBounds(100, 100, 470, 400);
        setTitle("Update Library");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//this is the code for the top JPanel and all of its contents.
		JPanel top = new JPanel();
		top.add(enterTrack);
		enterTrack.setBackground(Color.BLACK);
		enterTrack.setForeground(Color.ORANGE);
		top.add(trackNo);
		top.add(enterRating);
		enterRating.setBackground(Color.BLACK);
		enterRating.setForeground(Color.ORANGE);
		top.add(ratingEntry);
		top.setBackground(Color.BLACK);
		add("North", top);
		
		//this is the code for the middle JPanel and all of its contents.
		JPanel middle = new JPanel();
		middle.add(update);
		update.addActionListener(this);
		update.setBackground(Color.BLACK);
		update.setForeground(Color.ORANGE);
        middle.add(display);
		display.addActionListener(this);
		display.setBackground(Color.BLACK);
		display.setForeground(Color.ORANGE);
		middle.add(clear);
		clear.addActionListener(this);
		clear.setBackground(Color.BLACK);
		clear.setForeground(Color.ORANGE);
		middle.add(clear);
		middle.setBackground(Color.BLACK);
        //adding the sort, artist and reverse radio buttons to the
        //button group called ssar.
        ssar.add(sort);
		ssar.add(song);
        ssar.add(artist);
        ssar.add(reverse);
        //the sort, artist and reverse radio buttons are added to the
        //middle j panel.
        middle.add(sort);
        sort.setBackground(Color.BLACK);
        sort.setForeground(Color.ORANGE);
        sort.addActionListener(this);
		middle.add(song);
		song.setBackground(Color.BLACK);
        song.setForeground(Color.ORANGE);
        song.addActionListener(this);
        middle.add(artist);
        artist.setBackground(Color.BLACK);
        artist.setForeground(Color.ORANGE);
        artist.addActionListener(this);
        middle.add(reverse);
        reverse.setBackground(Color.BLACK);
        reverse.setForeground(Color.ORANGE);
        reverse.addActionListener(this);
		add("Center", middle);
		
		//this is the code for the bottom JPanel and all of its contents.
		JPanel bottom = new JPanel();
		bottom.add(libraryUpdate);
		bottom.setBackground(Color.ORANGE);
		add("South", bottom);
		
		//allows the JFrame to be seen, but doesn't allow it to be resized.
		setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
       


        if (e.getSource() == update)
        {
	   try {
            //defines the string variables "key" and "ratingStr", which both get their values from the ..
			//text fields "trackNo" and "ratingEntry".
			String key = trackNo.getText();
			String ratingStr = ratingEntry.getText();
			//a new variable is defined called "rating" which converts the text value of "ratingStr" ..
			//to an integer value.
			int rating = Integer.parseInt(ratingStr); 
			//uses the setRating method in the LibraryData class along with the ..
			//variables "key" and "rating" to set the Rating to the newly entered one ..
			//in the database.
			LibraryData.setRating(key, rating);
			//displays an output to show the changes made to the rating of a certain track have ..
			//taken place.
			libraryUpdate.setText("Updates made to the rating of the Track below are;");
			libraryUpdate.append("\n\n" + "Song Name: " + LibraryData.getName(key));
            libraryUpdate.append("\n" + "New Rating: " + stars(LibraryData.getRating(key)));
			
		}
			catch (Exception ex) {
            System.out.println(ex);
        }

		//validation for the text field where the Track Number is entered, this only allows the user of the Jukebox ..
		//to enter numerical values for the Track Number and not alphabetical values.
		try { 
				String numStr = trackNo.getText();
				int num = Integer.parseInt (numStr); 
			} 
			//the "catch" shown below is used to bring up a message on screen that asks the user to enter ..
			//a number for the Track Number, if they try to enter something that isn't a number.
			catch (NumberFormatException exception) { 
				JOptionPane.showMessageDialog(this, "Please enter a number for the Track Number!");
				libraryUpdate.setText("");
			} 
		
		//another bit of validation except this is for the text field where the Rating is entered, this only allows the user of ..
		//the Jukebox to enter numerical values for the Rating and not alphabetical values.
		try { 
				String rateStr = ratingEntry.getText();
				int rate = Integer.parseInt (rateStr); 
			} 
			//the "catch" shown below is used to bring up a message on screen that asks the user to enter ..
			//a number for the Rating, if they try to enter something that isn't a number.
			catch (NumberFormatException exception2) { 
				JOptionPane.showMessageDialog(this, "Please enter a number for the Rating!");
				libraryUpdate.setText("");
			} 
	}

       
        if (e.getSource() == display) {
            
			libraryUpdate.setText(LibraryData.listAll());
        }

		if (e.getSource() == clear) {
			//the line of code below is used to clear the selections of all ..
			//of the buttons contained in the button group called "ssar".
			ssar.clearSelection();
			//clears the text area.
			libraryUpdate.setText("");
		}

        if (sort.isSelected())
        {
            //the method "sortAll" in the Library Data class is called upon ..
			//to display the output in the text area called Library Update ..
			//when the "sort" radio button is selected on the GUI.
			libraryUpdate.setText(LibraryData.sortAll());
        }

		else if (song.isSelected())
		{
			//the method "songAll" in the Library Data class is called upon ..
			//to display the output in the text area called Library Update ..
			//when the "artist" radio button is selected on the GUI.
			libraryUpdate.setText(LibraryData.songAll());
		}

        else if (artist.isSelected())

        {
			//the method "artistAll" in the Library Data class is called upon ..
			//to display the output in the text area called Library Update ..
			//when the "artist" radio button is selected on the GUI.
			libraryUpdate.setText(LibraryData.artistAll());
        }


        else if (reverse.isSelected())
        {
			//the method "reverseAll" in the Library Data class is called upon ..
			//to display the output in the text area called Library Update ..
			//when the "reverse" radio button is selected on the GUI.
			libraryUpdate.setText(LibraryData.reverseAll());
		}
	}

	 private String stars(int rating) {
        String stars = "";
        for (int i = 0; i < rating; ++i) {
			stars += "*";
        }
        return stars;
    }
}