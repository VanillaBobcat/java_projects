import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Desktop;
import java.io.File;

public class Jukebox extends JFrame
                  implements ActionListener {
        JButton check = new JButton("Check Library");
        JButton playlist = new JButton("Create Playlist");
        JButton update = new JButton("Update Library");
		JButton help = new JButton("Help / Instructions");
        JButton quit = new JButton("Exit");
		JLabel welcome = new JLabel("~ Welcome to the Jukebox System's Main Menu ~");
		JLabel select = new JLabel("^ Select an option by clicking one of the buttons above ^");

    public static void main(String[] args) {
        new Jukebox();

    }
    
    public Jukebox() {
        setLayout(new BorderLayout());
        setSize(625, 120);
        setTitle("Jukebox");

        // close application only by clicking the quit button
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		
		//this is the code for the top JPanel and all of its contents.
        JPanel top = new JPanel();
		top.add(select);
		select.setForeground(Color.ORANGE);
		top.setBackground(Color.BLACK);
        add("South", top);
		
		//this is the code for the middle JPanel and all of its contents.
		JPanel middle = new JPanel();
		middle.add(welcome);
		welcome.setForeground(Color.ORANGE);
		middle.setBackground(Color.BLACK);
		add("Center", middle);
		
		//this is the code for the bottom JPanel and all of its contents.
        JPanel bottom = new JPanel();
        bottom.add(check); 
		check.setBackground(Color.BLACK);
		check.setForeground(Color.ORANGE);
		check.addActionListener(this);
        bottom.add(playlist); 
		playlist.setBackground(Color.BLACK);
		playlist.setForeground(Color.ORANGE);
		playlist.addActionListener(this);
        bottom.add(update); 
		update.setBackground(Color.BLACK);
		update.setForeground(Color.ORANGE);
		update.addActionListener(this);
        bottom.add(help);
		help.addActionListener(this);
		help.setBackground(Color.BLACK);
		help.setForeground(Color.ORANGE);
		bottom.add(quit); 
		quit.addActionListener(this);
		quit.setBackground(Color.BLACK);
		quit.setForeground(Color.ORANGE);
		bottom.setBackground(Color.ORANGE);
        add("North", bottom);
		
		//this is the code for the left JPanel and all of its contents.
		JPanel left = new JPanel();
		left.setBackground(Color.YELLOW);
		add("West", left);
		
		//this is the code for the right JPanel and all of its contents.
		JPanel right = new JPanel();
		right.setBackground(Color.YELLOW);
		add("East", right);
		
		//allows the JFrame to be seen, but doesn't allow it to be resized.
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        //this is the code for the buttons called check, playlist, update and help.
		//the check button takes the user to the CheckLibrary section.
		if (e.getSource() == check) {
            new CheckLibrary();
		}
		//the playlist button takes the user to the CreatePlaylist section.
		if (e.getSource() == playlist) {
			new CreatePlaylist();
		}
		//the update button takes the user to the UpdateLibrary section.
		if (e.getSource() == update) {
			new UpdateLibrary();
		}
		//the help button brings up a help file for the Jukebox program which is ..
		//called "JukeboxHelpFile.txt" when it is clicked on.
		if (e.getSource() == help) {
			 if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try
			{
				desktop.edit(new File("JukeboxHelpFile.txt"));
			}

			catch (Exception ex)
			{
				JOptionPane.showMessageDialog(this, " ");
			}
			}
		}
			else if (e.getSource() == quit) {
            LibraryData.close();
            System.exit(0);
        }
    }
}