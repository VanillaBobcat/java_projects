// Skeleton version of LibraryData.java that links to a database.
// NOTE: You should not have to make any changes to the other
// Java GUI classes for this to work, if you complete it correctly.
// Indeed these classes shouldn't even need to be recompiled

import java.io.*;
import java.sql.*; // DB handling package
public class LibraryData {

    private static Connection connection;
    private static Statement stmt;

    static {
        // standard code to open a connection and statement to an Access database
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            // Assumes JukeboxLibrary.mdb is in the same folder as LibraryData.class
            String sourceURL = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=LibraryDB.mdb;";
            connection = DriverManager.getConnection(sourceURL, "admin", "");
            stmt = connection.createStatement();
        } catch (Exception e) {
            // shouldn't happen if DB is set up correctly
            System.out.println(e);
        }
    }


    public static String listAll() {
        String output = "";
        try {
            //
            ResultSet res = stmt.executeQuery("SELECT * FROM Library");
            while (res.next()) { // there is a result
                //
                output += res.getString(1) + " -- " + res.getString(2) + " -- " + res.getString(3) + "\n";
            }
		} 
		
		catch (Exception e) {
            System.out.println(e);
            return null;
        }
        return output;
    }
	
	//
    public static String sortAll() {
        String output = "";
        try {
            //
            ResultSet res = stmt.executeQuery("SELECT key, Name, Artist FROM Library ORDER BY key");
            while (res.next()) { // there is a result
                //
                output += res.getString(1) + " -- " + res.getString(2) + " -- " + res.getString(3) + "\n";
            }
		} 
		
		catch (Exception e) {
            System.out.println(e);
            return null;
        }
        return output;
    }
	
	//
	public static String songAll() {
        String output = "";
        try {
            //
			ResultSet res = stmt.executeQuery("SELECT DISTINCT Name FROM Library3 ORDER BY Name"); 
            while (res.next()) { // there is a result
                //
               output += res.getString(1) + "\n";
            }
		} 
		
		catch (Exception e) {
            System.out.println(e);
            return null;
        }
        return output;
    }

	//
    public static String artistAll() {
        String output = "";
        try {
            //
			ResultSet res = stmt.executeQuery("SELECT DISTINCT Artist FROM Library2 ORDER BY Artist"); 
            while (res.next()) { // there is a result
                //
               output += res.getString(1) + "\n";
            }
		} 
		
		catch (Exception e) {
            System.out.println(e);
            return null;
        }
        return output;
    }

	//
	public static String reverseAll() {
        String output = "";
        try {
            //
            ResultSet res = stmt.executeQuery("SELECT key, Name, Artist FROM Library ORDER BY key DESC");
            while (res.next()) { // there is a result
                //
                output += res.getString(1) + " -- " + res.getString(2) + " -- " + res.getString(3) + "\n";
            }
		} 
		
		catch (Exception e) {
            System.out.println(e);
            return null;
        }
        return output;
    }
   

    public static String getName(String key) {
        try {
            // Need single quote marks ' around the key field in SQL. This is easy to get wrong!
            // For instance if key was "04" the SELECT statement would be:
            // SELECT * FROM LibraryTable WHERE key = '04'
            ResultSet res = stmt.executeQuery("SELECT * FROM Library WHERE key = '" + key + "'");
            if (res.next()) { // there is a result
                // the name field is the second one in the ResultSet
                // Note that with  ResultSet we count the fields starting from 1
                return res.getString(2);
            } else {
                return null;
            }
		} 
		
		catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    public static String getArtist(String key) {
        try
        {
			ResultSet res = stmt.executeQuery("SELECT * FROM Library WHERE key = '" + key + "'");
			if (res.next()) {
				//the artist field is the third one in the ResultSet.
				return res.getString(3);
			} else {
		// If there's no result, then return the value "null".
        return null;
    }
		}
		
		catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}


    public static int getRating(String key) {
		try
		{
			ResultSet res = stmt.executeQuery("SELECT * FROM Library WHERE key = '" + key + "'");
                    if (res.next()) {
		//the rating field is the fourth one in the ResultSet.
                        return res.getInt(4);
		} else {
        // Similar to getName - use res.getInt(4). If no result, return -1
        return -1;
    }
		}

		catch (Exception e) {
			System.out.println(e);
			return -1;
		}
	}



    public static int getPlayCount(String key) {
		try
		{
			ResultSet res = stmt.executeQuery("SELECT * FROM Library WHERE key = '" + key + "'");
			if (res.next()) {

                    return res.getInt(5);
		} else {
		// Similar to getName - use res.getInt(5). If no result, return -1
        return -1;
	}
		}

		catch (Exception e)
		{
			System.out.println(e);
			return -1;
		}
    }

    public static void setRating(String key, int rating) {
        
		// SQL UPDATE statement required. For instance if rating is 5 and key is "04" then updateStr is
        // UPDATE Libary SET rating = 5 WHERE key = '04'
		
		//int currentRating = getRating(key);
		//int newRating = UpdateLibrary.ratingEntry.getText();
		//rating = newRating;

        String updateStr = "UPDATE Library SET rating = " + rating + " WHERE key = '" + key + "'";
        System.out.println(updateStr);
        try {
            stmt.executeUpdate(updateStr);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void incrementPlayCount(String key, int playCount) {
        // Similar to setRating - but must getPlayCount first and increment by 1

		playCount = getPlayCount(key);
		//increments the play count by 1.
		playCount++;
        String updateStr = "UPDATE Library SET playCount = " + playCount + " WHERE key = '" + key + "'";

        System.out.println(updateStr);
        try {
            stmt.executeUpdate(updateStr);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    // close the database
    public static void close() {
        try {
            connection.close();
        } catch (Exception e) {
            // this shouldn't happen
            System.out.println(e);
        }
    }
}