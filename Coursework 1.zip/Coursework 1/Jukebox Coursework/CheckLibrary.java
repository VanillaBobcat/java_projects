//imports abstract windows toolkit (awt) into java
import java.awt.*;
import java.awt.event.*;
//imports swing into java, this with the awt import allow us to use components such as JButtons ..
//and JLabels.
import javax.swing.*;

public class CheckLibrary extends JFrame
                  implements ActionListener {
	// creates a new text field called trackNo.
    JTextField trackNo = new JTextField(2);
	// creates a new text area called information.
    JTextArea information = new JTextArea(12, 45);
	// creates a new button which displays "List All Tracks".
    JButton list = new JButton("List All Tracks");
	// creates a new button which displays "Check Track".
    JButton check = new JButton("Check Track");
	//creates a new label displaying the message "Enter the Track Number".
	JLabel enterTrack = new JLabel("Enter the Track Number: ");
    
	public CheckLibrary() {
		//sets the layout as BorderLayout.
        setLayout(new BorderLayout());
		//sets the boundaries (involving the height and width) of the check library window.
        setBounds(100, 100, 550, 400);
		//sets the title of the window to "Check Library".
        setTitle("Check Library");
		//sets the Default Close Operation to DISPOSE_ON_CLOSE instead of ..
		// EXIT_ON_CLOSE which is found in the JFrame template.
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JPanel top = new JPanel();
		// the label, the text field are added to the top section of the window. 
        top.add(enterTrack);
		// the foreground colour of the label (the label text) is set to an orange colour.
		enterTrack.setForeground(Color.ORANGE);
        top.add(trackNo);
		// the background colour of the top section of the window is set to the colour black.
		top.setBackground(Color.BLACK);
		add("North", top);

		JPanel middle = new JPanel();
		//calls upon the public function called listAll in the LibraryData class.
        information.setText(LibraryData.listAll());
		// the two buttons are added to the middle section of the window.
		middle.add(list);
		// the background colour of the list button is set to black.
		list.setBackground(Color.BLACK);
		// the foreground colour of the list button is set to orange.
		list.setForeground(Color.ORANGE);
		// adds an action listener to listen out for when the button displaying "List All Tracks" is pressed.
        list.addActionListener(this);
		middle.add(check);
		// sets the background colour of the check button to black.
		check.setBackground(Color.BLACK);
		// sets the background colour of the check button to orange.
		check.setForeground(Color.ORANGE);
		// adds another action listener to listen out for when the button displaying "Check Track" is pressed.
        check.addActionListener(this);
		// the background colour of the middle section of the window is set to the colour black.
		middle.setBackground(Color.BLACK);
        add("Center", middle);
		
		JPanel bottom = new JPanel();
		// the information text area is added to the bottom section of the window.
		bottom.add(information);
		// the colour of the bottom section of the window is set to orange.
		bottom.setBackground(Color.ORANGE);
		add("South", bottom);
		// prevents the check library window from being resized.
        setResizable(false);
		// allows the check library window to be visible when the program is run.
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
       // places and displays the data from the library data class into the information text area when the .. 
	   // list button has been clicked on.
		if (e.getSource() == list) {
            information.setText(LibraryData.listAll());
        } else if (e.getSource() == check)
        {
			// declaration of a new string variable called key which gets the track number from the box it was entered.
            String key = trackNo.getText();
            String name = LibraryData.getName(key);
			//an if statement used to display the error message "No such track number" when either a ..
			//null value or a track number that doesn't exist is entered as a track number.
			if (name == null) {
                information.setText("No such track number.");
            } else {
				// if a value is entered as a track number then the name of the song, the track number and the artist are ..
				// displayed in the text area.
                information.setText(name + " - " + LibraryData.getArtist(key));
                information.append("\nRating: " + stars(LibraryData.getRating(key)));
                information.append("\nPlay count: " + LibraryData.getPlayCount(key));
            }
        }
    }
	// this is a private function called stars which provides the rating value for the song.
    private String stars(int rating) {
        String stars = "";
        for (int i = 0; i < rating; ++i) {
			stars += "*";
        }
        return stars;
    }
}