/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabeansudokupuzzle;

import java.awt.event.*;

// an example Controller class if MVC was to be applied to Sudoku puzzle.

/**
 *
 * @author Toby
 */
public class SudokuController implements ActionListener {
   
   SudokuBeanView theView;
   Puzzle theModel;
   PuzzleGenerator theModel2;
   //CellNoteView cnView;

  


   public SudokuController(SudokuBeanView sv, Puzzle pz, PuzzleGenerator pg) {
       theView = sv;
       theModel = pz;
       theModel2 = pg;
               //View = cnv;
       //viewCl = vc;
   }

    public void actionPerformed(ActionEvent a) {
       //methods for possible action performed stuff here
    }

 }
