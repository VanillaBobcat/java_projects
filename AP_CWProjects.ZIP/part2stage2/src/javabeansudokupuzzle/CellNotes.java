/*
 * CellNotes.java
 *
 * Created on 02 January 2011, 22:54
 */
package javabeansudokupuzzle;
import java.util.*;

/**
 * Represents a set of notes for a Sudoku puzzle.  
 * The individual notes are stored in a HashMap with the 
 * co-ordinates of the cell as key and the Note object as the 
 * value.
 */
public class CellNotes {
    // The HashMap in which the individual notes are stored
    private HashMap<CellCoordinates, Note> notes;
    /**
     * Default constructor.
     */
    public CellNotes() {
        notes = new HashMap<CellCoordinates, Note>();
    }
    /**
     * Adds a Note to the collection for a particular cell
     * @param cell The co-ordinates of the cell for which the note is being
     * added.
     * @param note The Note object containing the note for this cell.
     */
    public void addNote(CellCoordinates cell, Note note) {
        notes.put(cell, note);
    }
    /**
     * Get the note for a particular cell indicated by the co-ordinates.
     * @param cell The co-ordinates of the cell for which the note is to be
     * returned.
     * @return The Note object containing the note for this cell.
     */
    public Note getNote(CellCoordinates cell) {
        return notes.get(cell);
    }
    /**
     * Delete a note from the collection for a particular cell as
     * indicated by the co-ordinates.
     * @param cell The co-ordinates of the cell whose note is to be deleted.
     */
    public void deleteNote(CellCoordinates cell) {
        notes.remove(cell);
    }
}
