/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabeansudokupuzzle;

//an example View interface if MVC was to be applied to Sudoku puzzle.

/**
 *
 * @author Toby
 */
public interface View {
//method that all classes which implement View must use.
void use();
}
