 package helicopterquestionone;

import java.util.ArrayList;
import java.util.List;

/**
 * Main class that creates the Helicopter and Passengers
 */
public class RunHelicopterFlights {

    public static void main(String[] args) {

        // create a Helicopter
        Helicopter whirlybird = new Helicopter();

        // create  Passengers
        List<Passenger> passengerQueue = new ArrayList<Passenger>();
      
        for (int i = 0; i < 15; i++)
        
            passengerQueue.add(new Passenger((i + 1), whirlybird));
         //}
       // }

        // Run the Passengers (they will try to board the helicopter)
        for (Passenger p : passengerQueue) {
            //p.run();
            p.start();
        }
    }
}
