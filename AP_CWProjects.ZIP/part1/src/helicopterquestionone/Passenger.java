package helicopterquestionone;

/**
 * Class to represent a helicopter passenger
 */
public class Passenger extends Thread {
    private Helicopter theHelicopter;
    private int number; // the passenger's number in the queue
    /**
     * @param heli the Helicopter that the passenger
     * will board for their flight
     */
    public Passenger(int number, Helicopter heli) {
        this.number = number;
        theHelicopter = heli;
    }

    /**
     * When this method is called the passenger will attempt
     * to board the Helicopter.
     */
    public void run() {
        theHelicopter.passengerBoards(this);
    }

    /**
     * @return the number representing the passenger's number
     * in the queue
     */
    public int getNumber() {
        return number;
    }
}