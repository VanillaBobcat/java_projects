package helicopterquestionone;

import java.util.*;

/** 
 * Class to represent a helicopter which gives rides.  Passengers
 * can get in the helicopter and once it is full it will take off.
 */
public class Helicopter {

    // pasengers currently in the helicopter
    private List<Passenger> passengers;
    private Timer timer; // times the flight
    /**
     * Maximum number of passengers allowed in the helicopter
     */
    public static final int HELICOPTER_CAPACITY = 5;
    /**
     * Length of the flight in seconds
     */
    public static final int FLIGHT_LENGTH = 5;

    public Helicopter() {
        passengers = new ArrayList<Passenger>();
    }

    /**
     * Method that is called by a passenger who wishes to board the
     * helicopter.  When the helicopter is full the flight will take off,
     * @param passenger reference to the passenger who wants to get
     * into the helicopter.
     */
    public synchronized void passengerBoards(Passenger passenger) {
        //try {
        //start of while loop used to get passengers boarding to wait.
        while (getNumberOfPassengers() == HELICOPTER_CAPACITY) {
            try {
                wait();
            } catch (InterruptedException ex) {
                System.out.println(ex);
            }

        }
            
            //start of if loop allowing the passengers to get on the plane.
            if (getNumberOfPassengers() < HELICOPTER_CAPACITY) {
               System.out.println("Passenger " + passenger.getNumber() +
                       " boards helicopter");
               delayWhilePassengerSitsDown();
               passengers.add(passenger);
            }

            //start of another if loop, which is seperate from the while loop,
            //which allows the Helicopter to take off when it is full.
            if (getNumberOfPassengers() == HELICOPTER_CAPACITY) {
                takeOff();
            }
        //will hopefully get the other passengers to take off.
        //} finally {
            //takeOff();
        //}
    }

    /**
     * Empties the Helicopter of passengers.
     */
    private synchronized void allPassengersGetOut() {

        passengers.clear();
        System.out.println("All Passengers get out of helicopter");

        //notifies the waiting threads that the helicopter is free.
        notifyAll();
    }

    /**
     * @return The number of passengers currently in the helicopter
     */
    private int getNumberOfPassengers() {
        return passengers.size();
    }

    /**
     * Method that starts the flight..  The length of the flight is controlled
     * by the constant: FLIGHT_LENGTH
     */
    private void takeOff() {
        System.out.println("Flight takes off");

        // start a timer to control the length of the flight
        timer = new Timer();
        timer.schedule(new FlightTimer(), FLIGHT_LENGTH * 1000);
    }

    /**
     * Method called at the end of the flight.
     */
    private void land() {
        System.out.println("Flight lands");
        allPassengersGetOut();
    }

    /** 
     * Method called to simulate a short delay while a passenger settles 
     *  into the Helicopter
     */
    private void delayWhilePassengerSitsDown() {
        try {
            Thread.sleep((int) ((Math.random() * 10) + 1));
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Inner class used to land the flight after the timer has expired.
     */
    class FlightTimer extends TimerTask {

        public void run() {
            land();
            timer.cancel();
        }
    }

}
