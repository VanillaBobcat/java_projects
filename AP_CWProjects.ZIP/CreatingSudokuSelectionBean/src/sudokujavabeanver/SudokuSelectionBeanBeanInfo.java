
package sudokujavabeanver;

import java.beans.*;
import java.awt.Image;

public class SudokuSelectionBeanBeanInfo extends SimpleBeanInfo {

    public PropertyDescriptor[] getPropertyDescriptors() {
        try {
            PropertyDescriptor val = new PropertyDescriptor("value", SudokuSelectionBean.class, "getValue", "setValue");

            PropertyDescriptor[] pds = new PropertyDescriptor[] {val};

            return pds;
            
        } catch (IntrospectionException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public Image getIcon(int iconKind) {
        switch(iconKind) {
            case BeanInfo.ICON_COLOR_16x16:
                return loadImage("Arrow.jpg");
                //return loadImage("selectionbeancolour_16.jpg");
            case BeanInfo.ICON_COLOR_32x32:
                return loadImage("Arrow_big.jpg");
            case BeanInfo.ICON_MONO_16x16:    
                return null;
            case BeanInfo.ICON_MONO_32x32:
                return null;
        }
        return null;
     }
   }
