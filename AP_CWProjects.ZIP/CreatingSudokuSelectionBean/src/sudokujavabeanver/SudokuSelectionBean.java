/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sudokujavabeanver;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.border.EtchedBorder;

/**
 *
 * @author gt904
 */
public class SudokuSelectionBean extends JPanel implements Serializable {
    
   
    public int numB;
    public JTextField txtNumberSelect = new JTextField(5);
    JButton btnDown = new JButton("<<"),
            btnUp = new JButton(">>");

    JLabel lblNumber = new JLabel("Value: ");
    
    //hardcoding the value is making it fail. which is why it keeps showing the
    //value set here.
    //JTextField txtNumberSelect = new JTextField(5);
   //txtNumberSelect = new JTextField(5);

    public SudokuSelectionBean() {
        this.setLayout(new FlowLayout());
        this.setBorder(new EtchedBorder());
       
        this.add(btnDown);
        btnDown.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                btnDownClicked();
            }
        });

        this.add(lblNumber);
        this.add(txtNumberSelect);

        //sets the default value of 1.
        setValue(1);
    
        this.add(btnUp);
        btnUp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                btnUpClicked();
            }
        });
      
    }

        public void setIncrement(int n) {
            numB = n;
            n++;
            setValue(n);
        }

        public void setDecrement(int n) {
            numB = n;
            n--;
            setValue(n);
        }

        public void setValue(int n) {
             numB = n;
             txtNumberSelect.setText(Integer.toString(n));
        }

        public void setNull() {
            txtNumberSelect.setText(null);
        }

        
        public int getValue() {
            String numTxt = txtNumberSelect.getText();
            numB = Integer.parseInt(numTxt);
            return numB;
        }


    public void btnDownClicked() {
            int value = getValue();
            setDecrement(value);
            System.out.println("down: " + getValue());

    }
    public void btnUpClicked() {
            int value = getValue();
            setIncrement(value);
            System.out.println("up: " + getValue());
        }
}


