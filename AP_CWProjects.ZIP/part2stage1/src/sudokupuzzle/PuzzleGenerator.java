/*
 * PuzzleGenerator.java
 *
 * Created on 02 January 2011, 15:29
 *
 */

package sudokupuzzle;

import static sudokupuzzle.Puzzle.*;
/**
 * Generates a grid representing a Sudoku puzzle.  At the moment it
 * only contains one puzzle but could be extended to contain more.
 * @author gillian
 */
public class PuzzleGenerator {

    // This is a 3-D array because it can contain many puzzles, each of which
    // contains many rows, each of which contains many values.
    char [] [] [] puzzles = {
        {{2,5,6,7,1,9,8,3,4},
         {1,3,8,4,2,5,7,6,9},
         {4,9,7,8,6,3,2,1,5},
         {9,8,1,5,4,7,3,2,6},
         {3,6,4,9,8,2,5,7,1},
         {5,7,2,6,3,1,9,4,8},
         {8,2,5,1,7,4,6,9,3},
         {6,4,3,2,9,8,1,5,7},
         {7,1,9,3,5,6,4,8,2}
        }
    };

    /** Creates a new instance of PuzzleGenerator */
    public PuzzleGenerator() {
    }
    /**
     * Get a two-dimensional array representing the grid of a Sudoku puzzle.
     * It will take one of the puzzles available in the puzzles array (only
     * one at present) and randomly blank out a number of cells to create
     * a puzzle to be completed.
     * @param numberOfEmpties The number of cells that are to be blanked out.
     * @return The 2-D array of chars representing the puzzle to be
     * solved by the user.
     */
    public char [][] getPuzzle(int numberOfEmpties) {
        char [] [] puzzle = puzzles[0]; // the the ones and only puzzle from the array
        
        int x, y;
        
        // Loop through the puzzle and randomly blank out the number of cells
        // specified in numberOfEmpties.
        for (int i = 0; i < numberOfEmpties; i++) {
            do {
                x = (int)(Math.random() * 9);
                y = (int)(Math.random() * 9);
            }  while (puzzle [x][y] == EMPTY_CELL);
            puzzle [x][y] = EMPTY_CELL;
        }
        return puzzle;
    }

}
