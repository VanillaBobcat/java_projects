/*
 * Puzzle.java
 *
 * Created on 02 January 2011, 09:07
 */

package sudokupuzzle;
import java.util.*;
import javax.swing.*;
import javax.swing.JOptionPane;

/**
 * Represents a single Sudoku puzzle.  There's not much intelligence 
 * here but it can check for duplicate entries and check to see if
 * the puzzle has been solved.  The size of the puzzle and regions is
 * represented using constants but it is only really tested for the normal
 * 9 x 9 puzzle consisting of 9 regions which are each 3 x 3.
 */
public class Puzzle {
    static final char EMPTY_CELL = ' '; // what is stored in an "empty" cell
    // constants to define the dimensions of the grid that forms the puzzle
    static final int ROW_LENGTH = 9;
    static final int COL_LENGTH = 9;
    static final int REGION_ROW_LENGTH = 3;
    static final int REGION_COL_LENGTH = 3;
    static final int NUM_REGIONS_ACROSS = ROW_LENGTH / REGION_ROW_LENGTH;
    static final int NUM_REGIONS_DOWN = COL_LENGTH / REGION_COL_LENGTH;
    
    private char [] [] grid; // the grid itself
    
    /**
     * Normal constructor to create an instance of the Puzzle.
     * @param grid Two dimensional array representing the puzzle.
     */
    public Puzzle(char [] [] grid) {
        this.grid = grid;
    }
    /**
     * Default constructor but not really intended to be used.  If
     * used it will create a Puzzle with no values filled in.
     */
    public Puzzle() {
        grid = new char [ROW_LENGTH] [COL_LENGTH];
        for (char [] row : grid) {
            Arrays.fill(row, EMPTY_CELL);
        }
    }
    /**
     * Get the value stored in a particular cell.
     * @param x x co-ordinate of cell
     * @param y y co-ordinate of cell
     * @return value stored in the cell.
     */
    public char getCell(int x, int y) {
        return grid[x][y];
    }
    
    /**
     * Set the value for a particular cell.
     * @param x x co-ordinate of the cell.
     * @param y y co-ordinate of the cell.
     * @param value value that the cell is to contain.
     */
    public void setCell(int x, int y, char value) {
        grid [x] [y] = value;
    }
    
    /**
     * Return the number of cells in the current Puzzle which are
     * empty.
     * @return The number of empty cells.
     */
    public int getEmptyCellsCount() {
        int count = 0;
        for (char [] row : grid) {
            for (char cell :row) {
                if (cell == EMPTY_CELL) {
                    count++;
                }
            }
        }
        return count;
    }
/**
 * A static inner class that represents the x/y co-ordinates
 * for a pair of cells in the Puzzle.  Used by the code
 * that detects duplicates.
 */    
    private static class CellCoordinatesPair {
        private CellCoordinates coords1, coords2;
        public CellCoordinatesPair(CellCoordinates coords1, CellCoordinates coords2) {
            this.coords1 = coords1;
            this.coords2 = coords2;
        }
    /**
     * Provide a string representation of the pair of co-ordinates.
     * @return The string representation in the form (x1,y1),(x2,y2)
     */        
        public String toString() {
            return coords1.toString() + "," + coords2.toString();
        }
    /**
     * Override default hashCode() method so that the HashMap will
     * work properly
     * @return The hash code computed from the sum of the co-ordinates
     */          
        public int hashCode() {
            return (coords1.hashCode() + coords2.hashCode());
        }
    /**
     * Override default equals() so that the HashMap will
     * work properly
     * @return true if the pair of co-ordinates are duplicated - note that
     * the order of the pair doesn't matter in detecting duplicates.
     */          
        public boolean equals(Object o) {
            if (o instanceof CellCoordinatesPair) {
                CellCoordinatesPair other = (CellCoordinatesPair) o;
                
                // note that (2,3),(7,5) is equal to (2,3),(7,5) and (7,5),(2,3)
                return (this.coords1.equals(other.coords1) &&  this.coords2.equals(other.coords2))
                        ||
                       (this.coords1.equals(other.coords2) &&  this.coords2.equals(other.coords1)); 
            }
            return false;
        }
    }
    
    /**
     * Get the co-ordinates of all pairs of duplicate cells.  Checks rows,
     * columns and regions.  A given pair of cells are only returned once.
     * @return A 3-dimensional array of ints representing all the x, y 
     * co-ordinates of pairs of duplicate numbers.  So if cell (2,3) 
     * and (2,7) are duplicates and so are cells (4,5) and (6,5) then
     * the array returned will be:
     * 
     * {{{2,3},{2,7}},{{4,5},{6,5}}}
     */
    public int [][][] getCoordinatesOfDuplicates() {
        
    // use a HashSet to store the duplicates so that any given pair of
    // co-ordinates are only stored once.
        HashSet<CellCoordinatesPair> duplicates = new HashSet<CellCoordinatesPair>();
        
    // check rows for duplicates
        for (int rowCount = 0; rowCount < grid.length; rowCount++) {
            char [] row = grid[rowCount];
            // check a row
            for (int i = 0; i < (row.length - 1); i++) {
                // check this cell against all others in the row
                for (int j = (i + 1); j < row.length; j++) {
                    if (row[i] != EMPTY_CELL && row[i] == row [j]) { // duplicate found
                        duplicates.add(new CellCoordinatesPair(
                                new CellCoordinates(rowCount, i), new CellCoordinates(rowCount, j)));
                    }
                }
            }
        }
        
    // check columns for duplicates
        for (int colCount = 0; colCount < grid[0].length; colCount++) {
            // check a column
            for (int i = 0; i < (grid.length - 1); i++) {
                // check this cell against all others in the column
                for (int j = (i + 1); j < grid.length; j++) {
                    if (grid[i][colCount] != EMPTY_CELL && grid[i][colCount] == grid[j][colCount]) { // duplicate found
                        duplicates.add(new CellCoordinatesPair(
                                new CellCoordinates(i, colCount), new CellCoordinates(j, colCount)));
                    }
                }
            }
        }
        
// check regions (i.e. the 3 x 3 sub-grids) for duplicates
        for (int regionCount = 0; regionCount < (NUM_REGIONS_ACROSS * NUM_REGIONS_DOWN); regionCount++) {
            
            // flatten region into 1 dimensional array first
            // so we can treate as a row
            char [] flatRegion = new char [REGION_ROW_LENGTH * REGION_COL_LENGTH];
            int regionX = regionCount % NUM_REGIONS_ACROSS;
            int regionY = regionCount / NUM_REGIONS_ACROSS;
            int topX = regionX * REGION_ROW_LENGTH;
            int topY = regionY * REGION_COL_LENGTH;
            for (int i = 0; i < REGION_ROW_LENGTH; i++) {
                for (int j = 0; j < REGION_COL_LENGTH; j++) {
                    flatRegion [(i * REGION_ROW_LENGTH) + j]
                            = grid[topX + i] [topY + j];
                }
            }
            for (int i = 0; i < (flatRegion.length - 1); i++) {
                // check this cell against all others in the region
                for (int j = (i + 1); j < flatRegion.length; j++) {
                    if (flatRegion[i] != EMPTY_CELL && flatRegion[i] == flatRegion [j]) { // duplicate found
                        
                        duplicates.add(new CellCoordinatesPair(
                                new CellCoordinates(topX + (i / REGION_ROW_LENGTH),
                                topY + (i % REGION_ROW_LENGTH)),
                                new CellCoordinates(topX + (j / REGION_ROW_LENGTH),
                                topY + (j % REGION_ROW_LENGTH))));
                    }
                }
            }
        }
        
// prepare what we have found for return
        int numberOfDuplicates = duplicates.size();
        if (numberOfDuplicates == 0)
            return null;
        int [][][] duplicateArray = new int [numberOfDuplicates] [2] [2];
        
        int count = 0;
        for (CellCoordinatesPair pair : duplicates) {
            duplicateArray [count][0][0] = pair.coords1.getX();
            duplicateArray [count][0][1] = pair.coords1.getY();
            duplicateArray [count][1][0] = pair.coords2.getX();
            duplicateArray [count][1][1] = pair.coords2.getY();
            count++;
        }
        
// return the 3-D array containing the pairs of duplicate co-ordinates
        return duplicateArray;
    }
    
    /**
     * Check to see if the Puzzle is solved i.e. completed with
     * no errors.
     * @return true if all cells have been filled and there are no 
     * duplicates, otherwise return false.
     */
    public boolean isSolved() {
        return (getCoordinatesOfDuplicates() == null) && (getEmptyCellsCount() == 0);
    }
}