/*
 * CellCoordinates.java
 *
 * Created on 02 January 2011, 22:35
 *
 */

package sudokupuzzle;

/**
 * Represents the x, y co-ordinates for a cell in a Sudoku puzzle.
 */
public class CellCoordinates {
    
    private int x, y; // the co-ordinates
    /**
     * Standard constructor.
     * @param x x co-ordinate of the cell.
     * @param y y co-ordinate of the cell.
     */
    public CellCoordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }
    /**
     * Get the x co-ordinate of this cell.
     * @return x co-ordinate of the cell.
     */
    public int getX() {
        return x;
    }
    /**
     * Get the y co-ordinate of this cell.
     * @return x co-ordinate of the cell.
     */
    public int getY() {
        return y;
    }    
    /**
     * Provide a string representation of the pair of co-ordinates.
     * @return The string representation in the form (x, y)
     */
    public String toString() {
        return "(" + this.x + "," + this.y + ")";
    }
    /**
     * Override default hashCode() method
     * @return The hash code computed from the sum of the co-ordinates
     */
    public int hashCode() {
        return (x + y);
    }
    /**
     * Override default equals()
     * @return true if the pair of co-ordinates are duplicated
     * @param o reference to another CellCoordinates object.
     */
    public boolean equals(Object o) {
        if (o instanceof CellCoordinates) {
            CellCoordinates other = (CellCoordinates) o;
            
            return this.x == other.x && this.y == other.y;
        }
        return false;
    }
}

