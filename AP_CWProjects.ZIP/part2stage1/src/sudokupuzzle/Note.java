/*
 * Note.java
 *
 * Created on 02 January 2011, 23:24
 *
 */

package sudokupuzzle;

import static sudokupuzzle.TriWay.*;

/**
 *
 * A note for an individual cell in a Sudoku puzzle.
 * The user can use the note to indicate the likely
 * values of the cell (stored in an array) and some
 * free text (stored in a String).
 */
public class Note {
    // the array of possible values
    private TriWay [] array;
    // the free text note
    private String text;
    /**
     * Create a new Note.
     * @param array An array of TriWays indicating values that the user
     * thinks the cell might contain e.g. if array[2] is TRUE
     * that means they think the cell  contains the third
     * value.
     * @param text Some free text that the user has entered as a note for
     * the cell.
     */
    public Note(TriWay[] array, String text) {
        this.array = array;
        this.text = text;
    }
    /**
     * Gets the array of values of this cell.
     * @return Returns the TriWay array which indicates what values
     * the user thinks this cell may contain.
     */
    public TriWay [] getArray() {
        return array.clone();
    }
    /**
     * Set the TriWay array.
     * @param array TriWay array indicating values the user thinks this
     * cell might contain.
     */
    public void setArray(TriWay[] array) {
        this.array = array;
    } 
    /**
     * Get the free text note associated with this cell.
     * @return The String containing the free text note associated 
     * with this cell.
     */
    public String getText() {
        return text;
    }    
    /**
     * Set the free text note associated with this cell.
     * @param text A string containing the free text note for this cell.
     */
    public void setText(String text) {
        this.text = text;
    }    
    /**
     * Indicated if this note is empty.
     * @return True is array contains all MAYBE values and the free
     * text note is blank.  True otherwise.
     */
    public boolean isEmpty () {
        boolean hasData = false;
        // Check the array. If it is not null and contains any
        // values other than MAYBE then
        // the note has data and so is not empty.
        if (array != null) {
            for (TriWay t: array) {
                hasData = t != MAYBE ? true : hasData;
            }
        }
        // Check the text string.  If it contains anything other than spaces then
        // the note has data and so is not empty.
        if (text != null && !text.trim().equals("")) {
            hasData = true;
        }
        return !hasData; // reverse the truth value
    }
}
