/*
 * TriWay.java
 */

package sudokupuzzle;

/**
 *
 * @author wg05
 *
 * An enumerated type for indicating three possibilities.
 *
 * Whereas a variable of type Boolean can only be
 * true or false a variable of type TriWay can be
 * true, false or maybe.
 */
public enum TriWay {
    TRUE, FALSE, MAYBE

}
