
package buydvds;
    import javax.swing.*;
    import java.awt.*;
    import java.awt.event.*;
import java.util.ArrayList;
import java.io.*;
import java.util.Collections.*;
//import java.io.FileWriter;
//



public class buyDVDS extends JFrame implements ActionListener {
    /*various JButtons on the JFrame with various captions which are used for
     various things with their code in the actionPerformed section of this
     class.*/
    JButton modifyFrameBtn = new JButton("Save and Modify DVD Records");
    JButton displayFrameBtn = new JButton("Display Existing DVD Records");
    JButton instructionsBtn = new JButton("Click for Instructions");
    JButton exitBtn = new JButton("Exit");
    //
    JLabel welcome = new JLabel("~ Welcome to the BuyDVDS Information "
            + "Program ~");
    //
    /*ArrayList numberStore = new ArrayList<String> ();
    //String[] numberStore = new String[20];
    ArrayList nameStore = new ArrayList<String> ();
    //String[] nameStore = new String[20];
    ArrayList typeStore = new ArrayList<String> ();
    //String[] typeStore = new String[20];
    ArrayList descriptionStore = new ArrayList<String> ();
    //String[] descriptionStore = new String[20];
    //String[] priceStore = new String[20];
    ArrayList priceStore = new ArrayList<String> ();*/

    //String[] store = new String[5];
    //
    private JPanel upper, center, lower, left, right;

    public static void main(String[] args) throws IOException {
        //
        new buyDVDS();
    }

    public buyDVDS() {
        //setLayout(new FlowLayout());
        //sets the size of the JFrame to
        setSize(650, 200);
        //
        setTitle("BuyDVDs DVD Sales");

        //setBackground(Color.ORANGE);
        /*prevents the program from closing which the red X in the top ..
        right is clicked.*/
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        //the upper JPanel and it's contents.
        upper = new JPanel();
        //upper.setLayout(new FlowLayout());
        upper.setLayout(new GridLayout(11, 3));
        upper.setBackground(Color.BLACK);
        add(upper, "North");

        //the center JPanel and it's contents.
        center = new JPanel();
        center.setLayout(new FlowLayout());

        center.add(modifyFrameBtn);
        modifyFrameBtn.setBackground(Color.GREEN);
        modifyFrameBtn.setForeground(Color.BLACK);
        modifyFrameBtn.addActionListener(this);

        center.add(displayFrameBtn);
        displayFrameBtn.setBackground(Color.GREEN);
        displayFrameBtn.setForeground(Color.BLACK);
        displayFrameBtn.addActionListener(this);

        center.add(instructionsBtn);
        instructionsBtn.setBackground(Color.GREEN);
        instructionsBtn.setForeground(Color.BLACK);
        instructionsBtn.addActionListener(this);

        center.add(exitBtn);
        exitBtn.setBackground(Color.GREEN);
        exitBtn.setForeground(Color.BLACK);
        exitBtn.addActionListener(this);
        center.setBackground(Color.BLACK);
        add(center, "Center");

        //the lower JPanel and it's contents.
        lower = new JPanel();
        lower.setLayout(new FlowLayout());
        lower.add(welcome);
        welcome.setBackground(Color.GREEN);
        welcome.setForeground(Color.WHITE);
        lower.setBackground(Color.BLACK);
        add(lower, "South");

        //the left JPanel and it's contents.
        left = new JPanel();
        left.setLayout(new FlowLayout());
        left.setBackground(Color.GREEN);
        add(left, "West");

        //the right JPanel and it's contents.
        right = new JPanel();
        right.setLayout(new FlowLayout());
        right.setBackground(Color.GREEN);
        add(right, "East");
        /*sets the Rssizable value of the JFrame to false so it can't be
         resized and the Visible value of the JFrame to true so it can be seen
         by the user*/
        setResizable(false);
        setVisible(true);
    }

    /**
     * @param args the command line arguments
     */
   
   

    public void actionPerformed(ActionEvent e) {
  
        
        if (e.getSource() == modifyFrameBtn) {
            //sets the close operation for the Main Menu to dispose on close ..
            //so it can be closed by clicking the X in the right hand corner
            //without closing the whole program.
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            /*displays a JOptionPane indicating that the default close
              operation has changed and the window can be closed.*/
            JOptionPane.showMessageDialog(this, "Main Menu is now able to be "
                    + "closed using the X button");
            /*calls the public modifyDVDS() method in the modifyDVDS class
            which loads up the new JFrame for modifyDVDS.*/
            new modifyDVDS();
        }

        
        if (e.getSource() == displayFrameBtn) {
            //sets the close operation for the Main Menu to dispose on close ..
            //so it can be closed by clicking the X in the right hand corner
            //without closing the whole program.
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            JOptionPane.showMessageDialog(this, "Main Menu is now able to be "
                    + "closed using the X button");
            /*calls the public displayDVDS() method in the displayDVDS class
            which loads up the new JFrame for displayDVDS.*/
            new displayDVDS();
        }

        if (e.getSource() == instructionsBtn) {
            try {
            /*makes use of the desktop class to open the instructions file for
              this program which is called "readme.txt" when this button is
              clicked on. */
            if (Desktop.isDesktopSupported()) {
            Desktop dsktp = Desktop.getDesktop();
          
            dsktp.edit(new File("readme.txt"));
                }
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }

        }
    
        if (e.getSource() == exitBtn) {
            /*calls the method in storageDVDS called closeDBConnection which
              closes the connection to the database*/
            storageDVDS.closeDBConnection();
            //exits the program.
            System.exit(0);
        }
    }
}
