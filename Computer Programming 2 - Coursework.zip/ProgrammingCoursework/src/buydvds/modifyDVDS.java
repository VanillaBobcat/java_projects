/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buydvds;

    import javax.swing.*;
    import java.awt.*;
    import java.awt.event.*;
//used for the arraylists required to test the buttons for USE CASE 1.
import java.util.ArrayList;
import java.io.*;
import java.util.Collections.*;
import java.util.regex.*;
/**
 *
 * @author Toby
 */
public class modifyDVDS extends JFrame implements ActionListener {
    //
    //JFileChooser fileSelection = new JFileChooser();
    //
    //FileInputStream fileInStrm = new FileInputStream("uy87.txt");
    //InputStreamReader inStrmRead = new InputStreamReader(fileInStrm);
    //BufferedReader buffRead = new BufferedReader(inStrmRead);
    //
    //private FileWriter fileOut;
    //BufferedWriter buffOut = new BufferedWriter(fileOut);


    //selection of JLabels for labelling the JTextFields.
    JLabel numberLbl = new JLabel("DVD Number", JLabel.CENTER);
    JLabel nameLbl = new JLabel("DVD Name", JLabel.CENTER);
    JLabel typeLbl = new JLabel("DVD Type", JLabel.CENTER);
    JLabel descriptionLbl = new JLabel("DVD Description", JLabel.CENTER);
    JLabel priceLbl = new JLabel("DVD Price", JLabel.CENTER);
    JLabel imageLbl = new JLabel("DVD Image File", JLabel.CENTER);

    //selection of JTextFields for data entry.
    JTextField dvdNumber = new JTextField(5);
    JTextField dvdName  = new JTextField(30);
    JTextField dvdType = new JTextField(5);
    JTextField dvdDescription = new JTextField(40);
    JTextField dvdPrice = new JTextField(6);
    JTextField dvdImage = new JTextField(60);

    //selection of JButtons used for various actions.
    JButton addBtn = new JButton("Add");
    JButton editBtn = new JButton("Edit Record");
    JButton editNameBtn = new JButton("Edit Name");
    JButton editTypeBtn = new JButton("Edit Type");
    JButton editDescBtn = new JButton("Edit Description");
    JButton editPriceBtn = new JButton("Edit Price");
    JButton editCoverBtn = new JButton("Edit Cover Image");
    JButton deleteBtn = new JButton("Delete Record");
    JButton clearBtn = new JButton("Clear the Screen");
    JButton backBtn = new JButton("Back to Main Menu");

    //the JTextArea used for outputting certain information.
    JTextArea opDVD = new JTextArea("");

    //the ArrayLists used for completing USE CASE 1.
    ArrayList numberStore = new ArrayList<String> ();
    ArrayList nameStore = new ArrayList<String> ();
    ArrayList typeStore = new ArrayList<String> ();
    ArrayList descriptionStore = new ArrayList<String> ();
    ArrayList priceStore = new ArrayList<String> ();


    private JPanel upper, center, lower;

     public static void main(String[] args) throws IOException {
        new modifyDVDS();
    }

    public modifyDVDS() {
            //setLayout(new FlowLayout());
        setSize(800, 600);
        setTitle("Modification of the DVD Record Information");

        //setBackground(Color.ORANGE);
        /*prevents the program from closing which the red X in the top ..
        right is clicked.*/
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        upper = new JPanel();
        upper.setLayout(new GridLayout(20, 3));
        
        upper.add(numberLbl);
        numberLbl.setForeground(Color.WHITE);
        upper.add(dvdNumber);
        upper.add(nameLbl);
        nameLbl.setForeground(Color.WHITE);
        upper.add(dvdName);
        upper.add(typeLbl);
        typeLbl.setForeground(Color.WHITE);
        upper.add(dvdType);
        upper.add(descriptionLbl);
        descriptionLbl.setForeground(Color.WHITE);
        upper.add(dvdDescription);
        upper.add(priceLbl);
        priceLbl.setForeground(Color.WHITE);
        upper.add(dvdPrice);
        upper.add(imageLbl);
        imageLbl.setForeground(Color.WHITE);
        upper.add(dvdImage);

        upper.setBackground(Color.BLACK);
        add(upper, "North");


        center = new JPanel();
        center.setLayout(new FlowLayout());
        center.add(addBtn);
        addBtn.setBackground(Color.GREEN);
        addBtn.setForeground(Color.BLACK);
        addBtn.addActionListener(this);

        center.add(editBtn);
        editBtn.setBackground(Color.GREEN);
        editBtn.setForeground(Color.BLACK);
        editBtn.addActionListener(this);

        center.add(editNameBtn);
        editNameBtn.setBackground(Color.GREEN);
        editNameBtn.setForeground(Color.BLACK);
        editNameBtn.addActionListener(this);

        center.add(editTypeBtn);
        editTypeBtn.setBackground(Color.GREEN);
        editTypeBtn.setForeground(Color.BLACK);
        editTypeBtn.addActionListener(this);

        center.add(editDescBtn);
        editDescBtn.setBackground(Color.GREEN);
        editDescBtn.setForeground(Color.BLACK);
        editDescBtn.addActionListener(this);

        center.add(editPriceBtn);
        editPriceBtn.setBackground(Color.GREEN);
        editPriceBtn.setForeground(Color.BLACK);
        editPriceBtn.addActionListener(this);

        center.add(editCoverBtn);
        editCoverBtn.setBackground(Color.GREEN);
        editCoverBtn.setForeground(Color.BLACK);
        editCoverBtn.addActionListener(this);

        center.add(deleteBtn);
        deleteBtn.setBackground(Color.GREEN);
        deleteBtn.setForeground(Color.BLACK);
        deleteBtn.addActionListener(this);

        center.add(clearBtn);
        clearBtn.setBackground(Color.GREEN);
        clearBtn.setForeground(Color.BLACK);
        clearBtn.addActionListener(this);

        center.add(backBtn);
        backBtn.setBackground(Color.GREEN);
        backBtn.setForeground(Color.BLACK);
        backBtn.addActionListener(this);

        center.setBackground(Color.BLACK);
        add(center, "Center");


        lower = new JPanel();
        lower.setLayout(new FlowLayout());
        lower.add(opDVD);
        
        lower.setBackground(Color.BLACK);
        add(lower, "South");

        
        setResizable(false);
        setVisible(true);
    }


    public void actionPerformed(ActionEvent e) {
      
        if (e.getSource() == addBtn) {

            try {

            String numStr = dvdNumber.getText();
            int numSave = Integer.parseInt(numStr);
            String nameSave = dvdName.getText();
            String typeSave = dvdType.getText();
            String descSave = dvdDescription.getText();
            String priceStr = dvdPrice.getText();
            int priceSave = Integer.parseInt(priceStr);

            String imageSave = dvdImage.getText();

            storageDVDS.saveAll(numSave, nameSave, typeSave, descSave,
                    priceSave, imageSave);
            //the JTextFields are all set to null when a value is saved.
            dvdNumber.setText(null);
            dvdName.setText(null);
            dvdType.setText(null);
            dvdDescription.setText(null);
            dvdPrice.setText(null);
            dvdImage.setText(null);
         //if one of the JTextFields has been made null then ..
         if (dvdNumber.getText() == null) {
            //show the record saved message.
            JOptionPane.showMessageDialog(this, "Record Saved! ");
         }
           //ArrayList code

               /*int i = 0;
               numberStore.add(i, dvdNumber.getText());
               i++;


               i = 0;
               nameStore.add(i, dvdName.getText());
               i++;


               i = 0;
               typeStore.add(i, dvdType.getText());
               i++;


               i = 0;
               descriptionStore.add(i, dvdDescription.getText());
               i++;


               i = 0;
               priceStore.add(i, dvdPrice.getText());
               i++;
      

         
               opDVD.append("DVD Number: " + numberStore.get(i-1) + " -");
          
               opDVD.append(" DVD Name: " + nameStore.get(i-1) + " -");

               opDVD.append(" DVD Type: " + typeStore.get(i-1) + "\n");

               opDVD.append("DVD Type: " + descriptionStore.get(i-1)
                       + " -");
  
               opDVD.append(" DVD Price: " + priceStore.get(i-1) + "\n");*/

               //try {
                   //this is the validation used for the DVD Number, it only
                   //allows the user to enter a number for the DVD Number and
                   //nothing else.
                   //String valNumberStr = dvdNumber.getText();
                   //int valNumber = Integer.parseInt(valNumberStr);

                   //String valNumbersStr = dvdPrice.getText();
                   //int valNumbers = Integer.parseInt(valNumbersStr);
            
            } catch (NumberFormatException ex) {
                   //
                   JOptionPane.showMessageDialog(this, "Please enter a number "
                           + "for the DVD Number or the DVD Price!");
                   // 
                   //numberStore.remove(0);
   
               }

               /*code used for outputting the values of the array lists and
                underneath it is the code used for displaying the latest value
                added into the array lists via the program beneath it in the
                JTextArea output (formerly called storageDVD, now called
                opDVD).*/

      //storageDVD.append("DVD Number: " + numberStore[i] + "\n" + "DVD Name: "
             //+ nameStore [i] + "DVD Type: " + store[2] +
             //"DVD Description: " + store[3] + "DVD Price: " + store[4]);
        /*storageDVD.append("" + dvdNumber.getText() + " " + dvdName.getText()
                + " " + dvdType.getText() + " "  + dvdDescription.getText()
                + " " + dvdPrice.getText() + "\n");*/
    }


        if(e.getSource() == editBtn) {
           String valueStr = JOptionPane.showInputDialog("Please insert the "
                   + "DVD Number of the record you wish to edit: ");
            int idValue = Integer.parseInt(valueStr);

            String nameUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Name: ");

            String typeUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Type: ");

            String descUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Description: ");


            String priceUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Price: ");

            String coverUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Cover Image Link: ");

            //getting the methods from the class storageDVDS using two
            //parameters.
            storageDVDS.editDVDName(nameUpdate, idValue);
            storageDVDS.editDVDType(typeUpdate, idValue);
            storageDVDS.editDVDDescription(descUpdate, idValue);
            storageDVDS.editDVDPrice(priceUpdate, idValue);
            storageDVDS.editDVDCover(coverUpdate, idValue);
            
         
         //the array lists.

         /*String editNumber;
         String existingNumberStr;
         editNumber = JOptionPane.showInputDialog("Please enter a new DVD"
                + "Number: ");
         existingNumberStr = JOptionPane.showInputDialog("Please input the "
                 + "number of the existing record you wish to replace the "
                 + "Number of ... \n"
                + "(0 is the last record entered, 1 is the 2nd to last "
                    + "record entered and so on.): ");
         int existingNumber = Integer.parseInt(existingNumberStr);
         //numberStore[existingNumber] = editNumber;
         //storeNumber[i] = editNumber;
         numberStore.set(existingNumber, editNumber);


         String editName;
         String existingNameStr;
         editName = JOptionPane.showInputDialog("Please enter a new DVD "
                 + "Name: ");
         existingNameStr = JOptionPane.showInputDialog("Please input the number "
                 + "of the existing record you wish to replace the Name of "
                 + "... \n"
                 + "(0 is the last record entered, 1 is the 2nd to last "
                    + "record entered and so on.): ");
         int existingName = Integer.parseInt(existingNameStr);
         //nameStore[existingName] = editName;
         //storeName[i] = editName;
         nameStore.set(existingName, editName);


         String editType;
         String existingTypeStr;
         editType = JOptionPane.showInputDialog("Please enter a new DVD Type: ");
         existingTypeStr = JOptionPane.showInputDialog("Please input the number "
                 + "of the existing record you wish to replace the Type of "
                 + "... \n"
                 + "(0 is the last record entered, 1 is the 2nd to last "
                    + "record entered and so on.): ");
         int existingType = Integer.parseInt(existingTypeStr);
         //typeStore[existingType] = editType;
         typeStore.set(existingType, editType);


         String editDescription;
         String existingDescriptionStr;
         editDescription = JOptionPane.showInputDialog("Please enter a new DVD "
                 + "Description: ");
         existingDescriptionStr = JOptionPane.showInputDialog("Please input the "
                 + "number of the existing record you wish to replace the "
                 + "Description of ... \n"
                 + "(0 is the last record entered, 1 is the 2nd to last "
                    + "record entered and so on.): ");
         int existingDescription = Integer.parseInt(existingDescriptionStr);
         //descriptionStore[existingDescription] = editDescription;
         descriptionStore.set(existingDescription, editDescription);

         String editPrice;
         String existingPriceStr;
         editPrice = JOptionPane.showInputDialog("Please enter a new DVD "
                 + "Price: ");
         existingPriceStr = JOptionPane.showInputDialog("Please input the "
                 + "number of the existing record you wish to replace the "
                 + "Price of ... \n"
                 + "(0 is the last record entered, 1 is the 2nd to last "
                    + "record entered and so on.): ");
         int existingPrice = Integer.parseInt(existingPriceStr);

         priceStore.set(existingPrice, editPrice);

             storageDVD.append("" + priceStore);*/
        }


        if (e.getSource() == editNameBtn) {
          try {
            String valueStr = JOptionPane.showInputDialog("Please insert the "
                   + "DVD Number of the record you wish to edit: ");
            int idValue = Integer.parseInt(valueStr);

            String nameUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Name: ");

           
            storageDVDS.editDVDName(nameUpdate, idValue);

            JOptionPane.showMessageDialog(this, "Name Edited!");

            } catch (NullPointerException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            } /*catch (FontFormatException ex) {
                  JOptionPane.showMessageDialog(this, "Selection Closed!",
                        "Closed", JOptionPane.CANCEL_OPTION);
       }*/
        }


        if (e.getSource() == editTypeBtn) {
           try {
            String valueStr = JOptionPane.showInputDialog("Please insert the "
                   + "DVD Number of the record you wish to edit: ");
            int idValue = Integer.parseInt(valueStr);

            String typeUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Type: ");

             /*using a pattern and a matcher for numerical validation on the
            typeUpdate input.*/
            Pattern patPat = Pattern.compile("[0-9]");
            Matcher matMat = patPat.matcher(typeUpdate);

        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only letters or"
                    + "symbols for the new DVD Type value!");
           }

            storageDVDS.editDVDType(typeUpdate, idValue);

            JOptionPane.showMessageDialog(this, "Type Edited!");

            } catch (NullPointerException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            }
        }


        if (e.getSource() == editDescBtn) {
          try {
            String valueStr = JOptionPane.showInputDialog("Please insert the "
                   + "DVD Number of the record you wish to edit: ");
            int idValue = Integer.parseInt(valueStr);

            String descUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Description: ");

            storageDVDS.editDVDDescription(descUpdate, idValue);
            JOptionPane.showMessageDialog(this, "Description Edited!");

         } catch (NullPointerException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            }
}


        if (e.getSource() == editPriceBtn) {
           try {
            String valueStr = JOptionPane.showInputDialog("Please insert the "
                   + "DVD Number of the record you wish to edit: ");
            int idValue = Integer.parseInt(valueStr);

            String priceUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Price: ");

            storageDVDS.editDVDPrice(priceUpdate, idValue);
            JOptionPane.showMessageDialog(this, "Price Edited!");

            } catch (NullPointerException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            }
        }


        if (e.getSource() == editCoverBtn) {
          try {
            String valueStr = JOptionPane.showInputDialog("Please insert the "
                   + "DVD Number of the record you wish to edit: ");
            int idValue = Integer.parseInt(valueStr);

            String coverUpdate = JOptionPane.showInputDialog("Please type the "
                    + "new DVD Cover Image Link:  ");

            storageDVDS.editDVDCover(coverUpdate, idValue);
            JOptionPane.showMessageDialog(this, "Cover Image Edited!");

            } catch (NullPointerException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
            }
        }


         if (e.getSource() == deleteBtn) {
           //
           try {
            String numDelStr = dvdNumber.getText();
            int numDel = Integer.parseInt(numDelStr);
            storageDVDS.deleteRecord(numDel);
            JOptionPane.showMessageDialog(this, "DVD Record Deleted!");
           } catch (NumberFormatException ex) {
                 JOptionPane.showMessageDialog(this, "Type the DVD Number of "
                         + "the Record you would like to delete in the DVD "
                         + "Number field.");
             }
        }


        if (e.getSource() == clearBtn) {
            //
            dvdNumber.setText(null);
            dvdName.setText(null);
            dvdType.setText(null);
            dvdDescription.setText(null);
            dvdPrice.setText(null);
            dvdImage.setText(null);

            opDVD.setText(null);
        }

        
       if (e.getSource() == backBtn) {
           //
           new buyDVDS();
       }

        
    }
}
