/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buydvds;

import java.sql.*;
import java.lang.Object.*;
import java.awt.Image;
    //possibly not needed.
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Toby
 */
public class storageDVDS {
    private static Connection cnct;
    private static Statement stmnt;

static {
        try {
            //
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            String dbURL = "jdbc:odbc:Driver={Microsoft Access Driver " + ""
                    + "(*.mdb)};DBQ=storageDVD.mdb;";
            //gets the connection with the values of (the URL, the type of User,
            //and any kind of password) in the brackets.
            cnct = DriverManager.getConnection(dbURL, "admin", "");
            /*sets the result set so it can move the cursor both forwards and
              backwards, instead of having a cursor that may only move forward
              which is the default setting of TYPE_FORWARD_ONLY.*/
            stmnt = cnct.createStatement(
              ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

public static String displayAllRecords() {
       
            //sets the variable to show nothing.
            String displayAll = "";
          try {
            //this piece of sql code selects all the fields from the Storage
            //table in the database.
            ResultSet resSet = stmnt.executeQuery("SELECT * FROM Storage");
          while (resSet.next()) {
              //resSet.first();
              //resSet.beforeFirst();
              displayAll += " DVD Number: " + resSet.getInt(1) + " -- Name: " +
                        resSet.getString(2) + " -- Type: "+ resSet.getString(3)
                        + " -- Description: " + resSet.getString(4) +
                        " -- Price: "+ resSet.getInt(5) + " \n";
            }
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE, 
                    null, ex);
            //JOptionPane.showMessageDialog(this, ex);
            return null;
        }
      return displayAll;
    }


public static String sortAllRecords() {
    String sortAll = "";
    try {
        ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName, "
                + "DVDType, DVDDescription, DVDPrice FROM Storage "
                + "WHERE DVDType = 'Film' OR DVDType = 'Music' ORDER BY "
                + "DVDName ASC");

        while(resSet.next()) {

                sortAll += " DVD Number: " + resSet.getInt(1) + " -- Name: " +
                        resSet.getString(2) + " -- Type: "+ resSet.getString(3)
                        + " -- Description: " + resSet.getString(4) +
                        " -- Price: "+ resSet.getInt(5) + " \n";
        }
    } catch (SQLException ex) {
        System.out.println("Sorting failed " + ex);
    }
    return sortAll;
}


public static String searchUsingDescription(String searchDesc) {

    String descriptionSearchResult = "";
        try {
            //
            /*ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName, "
                    + "DVDType, DVDDescription, DVDPrice FROM Storage "
                    + "WHERE DVDType IN ('Film', 'Music') AND " +
                    "DVDDescription LIKE '%" + searchDesc + "%'");*/

            ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName, "
                    + "DVDType, DVDDescription, DVDPrice FROM "
                    + "Storage WHERE DVDType IN ('Film', 'Music') AND " +
                    "DVDDescription LIKE '%" + searchDesc + "%'");


       while(resSet.next()) {

            descriptionSearchResult += " DVD Number: " + resSet.getInt(1) +
                    " -- Name: " + resSet.getString(2) + " -- Type: " + 
                    resSet.getString(3) + "-- Description: " +
                    resSet.getString(4) + "-- Price: " + resSet.getInt(5) +" \n\n";
        }
    } catch (SQLException ex) {
           System.out.println("Search Failed! " + ex);
    }
    return descriptionSearchResult;
}



public static String goToPreviousRecord(int idValue) {
       
            String prevRec = "";
            idValue--;
            //the .executeQuery is used as it executes an sql statement and then
            //returns one object from the result set.
            if (idValue == 0) {
                JOptionPane.showMessageDialog(null, "There is no record "
                        + "available before the first record!");
                return " No Record Available. ";
            }

        try {
            //ResultSet resSet.setFetchDirection(resSet.FETCH_REVERSE);
            ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName,"
                    + "DVDType, DVDDescription, DVDPrice FROM Storage "
                    + "WHERE DVDNumber = " + idValue);
            
            //sets the direction of the result set so it fetches the rows
            //and processes them in reverse order (from last to first).
            resSet.setFetchDirection(resSet.FETCH_REVERSE);
            while (resSet.previous()) {
                prevRec += " DVD Number: " + resSet.getInt(1) + " -- Name: "
                        + resSet.getString(2) + " -- Type: " 
                        + resSet.getString(3) + " -- Description: " 
                        + resSet.getString(4) + " -- Price: " 
                        + resSet.getInt(5) + " \n";
            }
        } catch (SQLException ex) {
            System.out.print("Previous Record Failed!" + ex);
        }
    return prevRec;
}


public static String goToNextRecord(int idValue)  {

            String nextRec = "";
            //increments the variable idValue that's given by 1.
            idValue++;
  
        try {
            ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName, "
                    + "" + "DVDType, DVDDescription, DVDPrice FROM Storage " +
                    "WHERE DVDNumber = " + idValue);
            
             
          while (resSet.next()) {
     
                nextRec += " DVD Number: " + resSet.getInt(1) + " -- Name: " +
                        resSet.getString(2) + " -- Type: " + resSet.getString(3)
                        + " -- Description: " + resSet.getString(4) +
                        " -- Price: " + resSet.getInt(5) + " \n";
                
            } 
     }  catch (SQLException ex) {
            System.out.println ("Next Record Failed!" +  ex);
     }
        return nextRec;
 }
          
            

public static String goToFirstRecord() {
    String firstRec = "";

 try {
      ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName, "
                    + "" + "DVDType, DVDDescription, DVDPrice FROM Storage");

     //
     resSet.first();

     firstRec +=  " DVD Number: " + resSet.getInt(1) + " -- Name: " +
                    resSet.getString(2) + " -- Type: " + resSet.getString(3)
                    + " -- Description: " + resSet.getString(4) +
                    " -- Price: " + resSet.getInt(5)+ " ";
     
 } catch (SQLException ex) {
     System.out.println ("First Record Failed!" + ex);
 }
    return firstRec;
}



public static String goToLastRecord()  {
    String lastRec = "";

 try {

   ResultSet resSet = stmnt.executeQuery("SELECT DVDNumber, DVDName, "
                    + "" + "DVDType, DVDDescription, DVDPrice FROM Storage");
                  
   //
   resSet.last();
      lastRec += " DVD Number: " + resSet.getInt(1) + " -- Name: " +
                    resSet.getString(2) + " -- Type: " + resSet.getString(3)
                    + " -- Description: " + resSet.getString(4) +
                    " -- Price: " + resSet.getInt(5) + " ";
} catch (SQLException ex) {
   System.out.print ("Last Record Failed!" + ex);
}
return lastRec;
}



public static String getDVDName(int idValue) {
        try {
            //
            //SELECT * FROM Storage WHERE value = '2'
            ResultSet resSet = stmnt.executeQuery("SELECT * FROM Storage "
                    + "WHERE DVDNumber = " + idValue);
            //
            if (resSet.next()) {
                return resSet.getString(2);
            } else {
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
            return null;
        }

 }



public static String getDVDType(int idValue) {
        try {
            //
            ResultSet resSet = stmnt.executeQuery("SELECT * FROM Storage "
                    + "WHERE DVDNumber = " + idValue);
            //
            if (resSet.next()) {
                return resSet.getString(3);
            } else {
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
            return null;
        }
}



public static String getDVDDescription(int idValue) {
        try {
            //
            ResultSet resSet = stmnt.executeQuery("SELECT * FROM "
                    + "Storage WHERE DVDNumber = " + idValue);
            //
            if (resSet.next()) {
                return resSet.getString(4);
            } else {
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
            return null;
        }
    }



public static String getDVDPrice(int idValue) {
        try {
            //
            ResultSet resSet = stmnt.executeQuery("SELECT * FROM "
                    + "Storage WHERE DVDNumber = " + idValue);
            //
            if (resSet.next()) {
                return resSet.getString(5);
            } else {
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
            return null;
        }
}



public static String getDVDImage(int idValue) {
    try {
        //
        ResultSet resSet = stmnt.executeQuery("SELECT * FROM Storage WHERE "
                + "DVDNumber = " + idValue);

        if (resSet.next()) {
            return resSet.getString(6);
            //return resSet.
                    //.getURL(6);
        } else {
            return null;
        }
    } catch (SQLException ex) {
        System.out.println(ex);
        return null;
    }
}



public static void saveAll(int numSave, String nameSave, String typeSave,
        String descSave, int priceSave, String imageSave) {
    //in order to use the ' symbols found in SQL statements, I needed two
    //quotations to put around them to mark them out as text as they are part
    //of the SQL statement required for inserting the values.
    String saving = ("INSERT INTO Storage (DVDNumber, DVDName, DVDType, "
            + "DVDDescription, DVDPrice, DVDCover) VALUES (" + numSave + ",'" +
            nameSave + "','" + typeSave + "','" + descSave + "'," + priceSave +
            ",'" + imageSave + "')");
    try {
      //executeUpdate is used for UPDATE, INSERT and DELETE SQL statements.
      stmnt.executeUpdate(saving);
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error with Save!");
    }
}



public static void deleteRecord(int numDel) {
    //
    String deleting = ("DELETE FROM Storage WHERE DVDNumber = " + numDel);
    //
    try {
        stmnt.executeUpdate(deleting);
    } catch (SQLException ex) {
            System.out.println("DELETE FAILED!!!" + ex);
        }
    }



public static void editDVDName(String nameUpdate, int idValue)  {

  String updating = ("UPDATE Storage SET DVDName = '" + nameUpdate + "' WHERE "
          + "DVDNumber =" + idValue);

 try {
    stmnt.executeUpdate(updating);
 } catch (SQLException ex) {
    System.out.print("NAME UPDATE FAILED!!!" + ex);
        }
 }



public static void editDVDType(String typeUpdate, int idValue)  {
  String updating = ("UPDATE Storage SET DVDType = '" + typeUpdate + "' WHERE "
          + "DVDNumber =" + idValue);

  try {
      stmnt.executeUpdate(updating);
    } catch (SQLException ex) {
        System.out.print("TYPE UPDATE FAILED!!!" + ex);
  }
}



public static void editDVDDescription(String descUpdate, int idValue)  {
    String updating = ("UPDATE Storage SET DVDDescription = '" + descUpdate +
            "' WHERE DVDNumber =" + idValue);

    try {
        stmnt.executeUpdate(updating);
    } catch (SQLException ex) {
        System.out.print("DESCRIPTION UPDATE FAILED!!!" + ex);
    }
}



public static void editDVDPrice(String priceUpdate, int idValue)  {
    String updating = ("UPDATE Storage SET DVDPrice = '" + priceUpdate +
            "' WHERE DVDNumber =" + idValue);

    try {
        stmnt.executeUpdate(updating);
    } catch (SQLException ex) {
        System.out.print("PRICE UPDATE FAILED!!!" + ex);
    }
}



public static void editDVDCover(String coverUpdate, int idValue) {
    String updating = ("UPDATE Storage SET DVDCover = '" + coverUpdate +
            "' WHERE DVDNumber =" + idValue);

    try {
        stmnt.executeUpdate(updating);
    } catch (SQLException ex) {
        System.out.println("COVER IMAGE UPDATE FAILED!!!" + ex);
    }
}



public static void closeDBConnection() {
        try {
            //closes the connection to the database at the end of the url
            //location (stated at the beginning of this class).
            cnct.close();
        } catch (SQLException ex) {
            Logger.getLogger(storageDVDS.class.getName()).log(Level.SEVERE,
                    null, ex);
        }
    }
}
