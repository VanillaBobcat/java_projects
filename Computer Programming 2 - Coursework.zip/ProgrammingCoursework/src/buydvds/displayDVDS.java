/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buydvds;
 import javax.swing.*;
    import java.awt.*;
    import java.awt.event.*;
import java.io.*;
import java.util.Collections.*;
import java.lang.*;

/*import used for pattern and matcher which found out about in the link below
  and made use of them in the program for JOptionPane validation purposes.

  http://www.roseindia.net/tutorial/java/swing/joptionpaneValidation.html*/
import java.util.regex.*;
/**
 *
 * @author Toby
 */
public class displayDVDS extends JFrame implements ActionListener {
    /*various JButtons on the JFrame with various captions which are used for
     various things with their code in the actionPerformed section of this
     class.*/
    JButton displayBtn = new JButton("Display All");
    JButton getBtn = new JButton("Get Record");
    JButton sortBtn = new JButton("Sort");
    JButton descSearchBtn = new JButton("Search");
    JButton webOutBtn = new JButton("Write to Web Page");
    JButton backBtn = new JButton("Back to Main Menu");
    JButton nextRecordBtn = new JButton("|>");
    JButton prevRecordBtn = new JButton("<|");
    /*used for skipping to the first record and skipping to the last record in
      the database.*/
    JButton skipStartBtn = new JButton("First <|");
    JButton skipEndBtn= new JButton("|> Last");
    //
    JButton imgDisplay = new JButton("Select DVD Image");
    JButton tbnailDisplay = new JButton("Show Thumbnail");
    //
    JRadioButton imgNotHideDisplay = new JRadioButton ("Show DVD Image", true);
    JRadioButton imgHideDisplay = new JRadioButton("Hide DVD Image", false);
    //used for displaying images and thumbnails in the program.
    JLabel imageLbl = new JLabel();
    /*used for displaying records that are saved in the external database, as
    well as viewing changes that have been made to the data stored in the
    database.*/
    JTextArea opDVD = new JTextArea(4, 15);
    //TextArea opDVD = new TextArea(4, 15);
    //
    JScrollPane scrollDVD = new JScrollPane(opDVD);
    //the JFileChooser used to save details as web pages.
    JFileChooser selectFile = new JFileChooser();
    //the various JPanels used.
    private JPanel upper, center, lower;



    public static void main(String[] args) throws IOException {
        //
        new displayDVDS();
    }

    public displayDVDS() {

        //sets the size of the JFrame to the width of 800 and the height of 600.
        setSize(800, 600);
        //sets the title of the JFrame to the string shown.
        setTitle("Displaying the DVD Record Information");
        //setBackground(Color.ORANGE);
        /*prevents the program from closing which the red X in the top ..
        right is clicked.*/
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        //the upper JPanel and it's contents.
        upper = new JPanel();
        upper.setLayout(new FlowLayout());
        //upper.setLayout(new GridLayout());

        upper.add(displayBtn);
        displayBtn.setBackground(Color.GREEN);
        displayBtn.setForeground(Color.BLACK);
        displayBtn.addActionListener(this);

        upper.add(sortBtn);
        sortBtn.setBackground(Color.GREEN);
        sortBtn.setForeground(Color.BLACK);
        sortBtn.addActionListener(this);

        upper.add(descSearchBtn);
        descSearchBtn.setBackground(Color.GREEN);
        descSearchBtn.setForeground(Color.BLACK);
        descSearchBtn.addActionListener(this);

        upper.add(getBtn);
        getBtn.setBackground(Color.GREEN);
        getBtn.setForeground(Color.BLACK);
        getBtn.addActionListener(this);

        upper.add(imgDisplay);
        imgDisplay.setBackground(Color.GREEN);
        imgDisplay.setForeground(Color.BLACK);
        imgDisplay.addActionListener(this);

        upper.add(tbnailDisplay);
        tbnailDisplay.setBackground(Color.GREEN);
        tbnailDisplay.setForeground(Color.BLACK);
        tbnailDisplay.addActionListener(this);

        upper.add(webOutBtn);
        webOutBtn.setBackground(Color.GREEN);
        webOutBtn.setForeground(Color.BLACK);
        webOutBtn.addActionListener(this);
       

        upper.setBackground(Color.BLACK);
        add(upper, "North");

        //the center JPanel and it's contents.
        center = new JPanel();
        center.setLayout(new FlowLayout());
        
        center.add(prevRecordBtn);
        prevRecordBtn.setBackground(Color.GREEN);
        prevRecordBtn.setForeground(Color.BLACK);
        prevRecordBtn.addActionListener(this);

        center.add(nextRecordBtn);
        nextRecordBtn.setBackground(Color.GREEN);
        nextRecordBtn.setForeground(Color.BLACK);
        nextRecordBtn.addActionListener(this);

        center.add(skipStartBtn);
        skipStartBtn.setBackground(Color.GREEN);
        skipStartBtn.setForeground(Color.BLACK);
        skipStartBtn.addActionListener(this);

        center.add(skipEndBtn);
        skipEndBtn.setBackground(Color.GREEN);
        skipEndBtn.setForeground(Color.BLACK);
        skipEndBtn.addActionListener(this);
        
        center.add(imgNotHideDisplay);
        imgNotHideDisplay.setBackground(Color.GREEN);
        imgNotHideDisplay.setForeground(Color.BLACK);
        imgNotHideDisplay.addActionListener(this);

        center.add(imgHideDisplay);
        imgHideDisplay.setBackground(Color.GREEN);
        imgHideDisplay.setForeground(Color.BLACK);
        imgHideDisplay.addActionListener(this);
        //
        ButtonGroup imgShowHide = new ButtonGroup();
        imgShowHide.add(imgNotHideDisplay);
        imgShowHide.add(imgHideDisplay);

        center.add(backBtn);
        backBtn.setBackground(Color.GREEN);
        backBtn.setForeground(Color.BLACK);
        backBtn.addActionListener(this);
        //center.add(imageLbl);
        center.setBackground(Color.BLACK);
        center.add(opDVD);
        //
        center.setBackground(Color.BLACK);
        
        
        //setPreferredSize(new Dimension(450, 110));
        //add(scrollDVD, BorderLayout.CENTER);

        add(center, "Center");

        //the lower JPanel and it's contents.
        lower = new JPanel();
        lower.setLayout(new FlowLayout());
        lower.add(imageLbl);
        lower.setBackground(Color.BLACK);
        //lower.add(opDVD);
        add(lower, "South");

        /*sets the Rssizable value of the JFrame to false so it can't be
         resized and the Visible value of the JFrame to true so it can be seen
         by the user*/
        setResizable(false);
        setVisible(true);

    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == displayBtn) {
            //clears the JTextArea before calling the method displayAllRecords()
            //located in the storageDVDS class.
            opDVD.setText("");
            opDVD.append("" + storageDVDS.displayAllRecords());
        }

        if(e.getSource() == getBtn) {
         try {
            String valueStr = JOptionPane.showInputDialog("Please enter DVD "
                    + "Number for the record you wish to view: ");
         //made use of pattern and matcher for validation of the JOptionPane.
            /*the pattern is used in order to precompile regaular expressions
            (such as the characters shown below) so they can be executed
            effeciently.*/
            Pattern patPat = Pattern.compile("[A-Z,a-z,&%$#@!()*^]");
            /*the matcher is then used to perform certain operations on a
             character sequence (like my input) by interpreting a pattern
             (shown above).*/
            Matcher matMat = patPat.matcher(valueStr);
            /*the matcher's .find() method is used to find any part of the
              input that matches the pattern above.*/
        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only numbers "
                     + "that are 1 or higher");
            }
            /*changes the variable valueStr into an integer value called
            idValue.*/
            int idValue = Integer.parseInt(valueStr);
            /*declares variables which call various methods from the storageDVDS
              class that obtain certain values from the records based on the
              idValue which is used as a parameter.*/
            String nameOut = storageDVDS.getDVDName(idValue);
            String typeOut = storageDVDS.getDVDType(idValue);
            String descOut = storageDVDS.getDVDDescription(idValue);
            String priceOutStr = storageDVDS.getDVDPrice(idValue);
            int priceOut = Integer.parseInt(priceOutStr);
            String imgimg = storageDVDS.getDVDImage(idValue);
            /* a new image ImageIcon called imageDB is created in order to
            create a new ImageIcon out of the method called below.*/
            ImageIcon imageDB = new ImageIcon(imgimg);
            /*outputs the Name, Type, Description and Price based on the
              variables declared above.*/

            opDVD.setText("");
            opDVD.append(" Name: " + nameOut + "  Type: " + typeOut +
                    "  Description: "+ descOut + "  Price: " + priceOut + " "
                    + "\n");

            imageLbl.setIcon(imageDB);

           }  catch (NumberFormatException ex) {
                  JOptionPane.showMessageDialog(this, "Selection Closed!",
                        "Cancel", JOptionPane.CANCEL_OPTION);
           } catch (NullPointerException ex) {
               JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
           }
        }


        if (e.getSource() == sortBtn) {
            //clears the JTextArea.
            opDVD.setText("");
            /*calls the methods sortAllRecords from the storageDVDS class which
              is displayed and output in the JTextArea.*/
            opDVD.setText("" + storageDVDS.sortAllRecords());
        }


        if (e.getSource() == descSearchBtn) {
            /*searchDesc is a string variable that's used to record the input
              for a search of records by their descriptions.*/
            String searchDesc = JOptionPane.showInputDialog("Please enter a "
                    + "whole or part of a Description: ");
            //opDVD.setText("");
            /*the JTextArea then displays the method searchUsingDescription
              from the storageDVDS class which uses the searchDesc variable as
              a parameter.*/
            opDVD.setText("" + storageDVDS.searchUsingDescription(searchDesc));
                JOptionPane.showMessageDialog(this, "No Results were Found!");
            }
        


        if (e.getSource() == webOutBtn) {
          try {
            //valueStr is once again used for JOptionPane input.
           String valueStr = JOptionPane.showInputDialog("Please enter DVD "
                    + "Number for the record you wish to obtain the "
                    + "details of: ");
           /*the pattern is used in order to precompile regaular expressions
            (such as the characters shown below) so they can be executed
            effeciently.*/
            Pattern patPat = Pattern.compile("[A-Z,a-z,&%$#@!()*^]");
            /*the matcher is then used to perform certain operations on a
             character sequence (like my input) by interpreting a pattern
             (shown above).*/
            Matcher matMat = patPat.matcher(valueStr);
            /*the matcher's .find() method is used to find any part of the
              input that matches the pattern above.*/
        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only numbers "
                     + "that are 1 or higher");
           }
           int idValue = Integer.parseInt(valueStr);
           /*methods from the class storageDVDS are used to call different
             parts of the record are displayed below.*/
           String webName = storageDVDS.getDVDName(idValue);
           String webType = storageDVDS.getDVDType(idValue);
           String webDesc = storageDVDS.getDVDDescription(idValue);
           String webPriceStr = storageDVDS.getDVDPrice(idValue);
           int webPrice = Integer.parseInt(webPriceStr);
           String imageCoverName = storageDVDS.getDVDImage(idValue);

           /*String imageCoverName = JOptionPane.showInputDialog("Please enter "
                   + "the URL link to the image file: ");*/
           
           /*JOptionPane displaying an information message that talks about
             any possible problems the user may have if the image does not
             show up on the web page.*/
           JOptionPane.showMessageDialog(this, "If the image " +
                  "for the record doesn't show up;\n Please check and make sure "
                  + "that the image and the web page are saved in the same "
                  + "place.\n Please also check that the image URL link saved "
                  + "into the DVDCover database field is correct.");
           
           // makes use of the JFileChooser's save dialog.
           selectFile.showSaveDialog(this);
           /* variable used in order to allow the user to save the file under
           the name they choose with the JFileChooser. */
           File nameOfFile = selectFile.getSelectedFile();
           /*a PrintWriter, BufferedWriter and FileWriter all used to write to
             a file that's named and saved by the user.*/
           PrintWriter printWrite = new PrintWriter( new BufferedWriter(
                   new FileWriter(nameOfFile + ".htm")));
           
           /*general contents of the web file that's named and then saved
             by the user.*/
           printWrite.println("<html><body><h1>BuyDVDS Webpage</h1>");
           printWrite.println();
           printWrite.println("<h2>Selected DVD Details</h2></BR>");
           printWrite.println();
           printWrite.println("<p1><b>DVD ID Number: </b>" + idValue + "<BR>");
           printWrite.println();
           printWrite.println("<b>DVD Name: </b>" + webName + "<BR>");
           printWrite.println();
           printWrite.println("<b>DVD Type: </b>" + webType + "<BR>");
           printWrite.println();
           printWrite.println("<b>DVD Description:</b> " + webDesc + "<BR>");
           printWrite.println();
           printWrite.println("<b>DVD Price: </b>" + webPrice + "<BR>");
           printWrite.println();
           printWrite.println("<b>DVD Cover Image </b><BR>");
           printWrite.println();
           //displaying an image based off the imageCoverName variable above.
           printWrite.println("<img src='" + imageCoverName + "'></p1>");
           printWrite.println("</body></html>");
           printWrite.close();
       } catch (IOException ex) {
           JOptionPane.showMessageDialog(this, ex);
       }  catch (NumberFormatException ex) {
                  JOptionPane.showMessageDialog(this, "Selection Closed!",
                        "Closed", JOptionPane.CANCEL_OPTION);
       } catch (NullPointerException ex) {
               JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
           }
        }




      if(e.getSource() == nextRecordBtn) {
          try {
           String valueStr = JOptionPane.showInputDialog("Please enter the "
                   + "current DVD Number: ");
         
            Pattern patPat = Pattern.compile("[A-Z,a-z,&%$#@!()*^]");
            Matcher matMat = patPat.matcher(valueStr);
           
        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only numbers "
                     + "that are 1 or higher");
           }
          
           int idValue = Integer.parseInt(valueStr);

           //displays the image in the program.

           opDVD.setText("" + storageDVDS.goToNextRecord(idValue));
           ////increments the idValue by 1 before getting the image.
           idValue++;
           String imgimg = storageDVDS.getDVDImage(idValue);
           //displays the image in the program.
           ImageIcon imageDB = new ImageIcon(imgimg);
           imageLbl.setIcon(imageDB);

          }  catch (NumberFormatException ex) {
                  JOptionPane.showMessageDialog(this, "Selection Closed!",
                        "Closed", JOptionPane.CANCEL_OPTION);
            } catch (NullPointerException ex) {
               JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
           }
        }

        
        if(e.getSource() == prevRecordBtn) {
         try {
           String valueStr = JOptionPane.showInputDialog("Please enter the "
                   + "current DVD Number: ");
           Pattern patPat = Pattern.compile("[A-Z,a-z,&%$#@!()*^]");
            Matcher matMat = patPat.matcher(valueStr);
           
        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only numbers "
                     + "that are 2 or higher");
            }
           int idValue = Integer.parseInt(valueStr);

           /*the JTextArea sets value as the result of the method called
             goToPreviousRecord() from storageDVDS which requires the idValue
             as an input.*/
           opDVD.setText("" + storageDVDS.goToPreviousRecord(idValue));
           //reduces the idValue by 1 before getting the image.
           idValue--;
           String imgimg = storageDVDS.getDVDImage(idValue);
           //displays the image in the program.
           ImageIcon imageDB = new ImageIcon(imgimg);
           imageLbl.setIcon(imageDB);

         } catch (NumberFormatException ex) {
                  JOptionPane.showMessageDialog(this, "Selection Closed!",
                        "Closed", JOptionPane.CANCEL_OPTION);
            } catch (NullPointerException ex) {
               JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
           }
        }


        if (e.getSource() == skipStartBtn) {
            /*clears the JTextArea and then displays the results of the method
              goToFirstRecord() from the storageDVDS class when clicked.*/
            opDVD.setText("");
            opDVD.setText("" + storageDVDS.goToFirstRecord());
        }


        if (e.getSource() == skipEndBtn) {
            /*clears the JTextArea and then displays the results of the method
              goToLastRecord() from the storageDVDS class when clicked.*/
            opDVD.setText("");
            opDVD.setText("" + storageDVDS.goToLastRecord());

        }


        if (e.getSource() == backBtn) {
            //creates a new instance of the method called buyDVDS();
            new buyDVDS();
        }


        if (e.getSource() == imgDisplay) {
         try {
            //a variable called valueStr prompts the user to enter the record
             // number for the image they wish to view on screen
            String valueStr = JOptionPane.showInputDialog("Please type the "
                    + "record number for the image you wish to view: ", 
                    JOptionPane.YES_NO_OPTION);

            Pattern patPat = Pattern.compile("[A-Z,a-z,&%$#@!()*^]");
            Matcher matMat = patPat.matcher(valueStr);
            //
        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only numbers "
                     + "that are 1 or higher");
            }
            /*this valueStr variable input is converted into an integer called
              idValue for later use.*/
            int idValue = Integer.parseInt(valueStr);
            /*the string variable imgimg calls the method from the storageDVDS
             class called getDVDImage which requires the input of idValue as
             * a parameter. */
            String imgimg = storageDVDS.getDVDImage(idValue);
            /* a new image ImageIcon called imageDB is created in order to
            create a new ImageIcon out of the method called below.*/
            ImageIcon imageDB = new ImageIcon(imgimg);

            //sets the size for the label that will display the image.
            imageLbl.setSize(200, 200);

            imageLbl.setIcon(imageDB);
            } catch (NumberFormatException ex) {
                  JOptionPane.showMessageDialog(this, "Selection Closed!",
                        "Closed", JOptionPane.CANCEL_OPTION);
            } catch (NullPointerException ex) {
               JOptionPane.showMessageDialog(this, "Cancel Option Selected",
                        "Cancel", JOptionPane.CANCEL_OPTION);
           }
        }


        if (e.getSource() == tbnailDisplay) {
            String valueStr = JOptionPane.showInputDialog("Please type the "
                    + "record number for the thumbnail you wish to view: ",
                    JOptionPane.YES_NO_OPTION);

            Pattern patPat = Pattern.compile("[A-Z,a-z,&%$#@!()*^]");
            Matcher matMat = patPat.matcher(valueStr);
            //
        if (matMat.find()){
            JOptionPane.showMessageDialog(null, "Please enter only numbers "
                     + "that are 1 or higher");
            }

            int idValue = Integer.parseInt(valueStr);

            String imgimg = storageDVDS.getDVDImage(idValue);

            ImageIcon imageDB = new ImageIcon(imgimg);

           
        /*used a small fraction of the code from the link below to create
        a thumbnail of an image that's retrieved from a record in the database.

        http://jcsnippets.atspace.com/java/gui-graphics/create-thumbnail.html*/
            ImageIcon imageThumbDB = new ImageIcon
                    (imageDB.getImage().getScaledInstance(180, -1,
                    Image.SCALE_FAST));
            /*the JLabel sets it's icon as the thumbnail image instead of the
              regular one.*/
            imageLbl.setIcon(imageThumbDB);
            // thumbnailDVDS.getDVDThumbnail(thumbSize, imageDB.Y);

            //imageThumbDB = new ImageIcon(imageDB.getImage().getScaledInstance())
        }

        if (imgNotHideDisplay.isSelected()) {
            /*sets the label's visibility to true so the image on the label
              is shown on screen. */
            imageLbl.setVisible(true);

        }


        if (imgHideDisplay.isSelected()) {
            /*sets the label's visibility to false so the image on the
              label is hidden.*/
            imageLbl.setVisible(false);
        }
    }

}
