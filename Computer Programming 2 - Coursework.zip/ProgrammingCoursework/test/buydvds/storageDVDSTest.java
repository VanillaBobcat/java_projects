/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buydvds;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Toby
 */
public class storageDVDSTest {

    public storageDVDSTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of displayAllRecords method, of class storageDVDS.
     */
    @Test
    public void testDisplayAllRecords() {
        System.out.println("displayAllRecords");

   String expResult = " DVD Number: 1 -- Name: Mega Man 9 -- Type: Game -- Description: retro platformer game -- Price: 6 \n" +
 " DVD Number: 2 -- Name: Wild Wild West -- Type: Film -- Description: film set in the wild west -- Price: 19 \n" +
 " DVD Number: 3 -- Name: Inception -- Type: Film -- Description: dreams sleep -- Price: 24 \n" +
 " DVD Number: 4 -- Name: A Weekend In The City -- Type: Music -- Description: Bloc Party -- Price: 9 \n" +
 " DVD Number: 5 -- Name: Tekken 6 -- Type: Game -- Description: 3D fighting game -- Price: 30 \n" +
 " DVD Number: 6 -- Name: Mellon Collie And The Infinite Sadness -- Type: Music -- Description: The Smashing Pumpkins -- Price: 10 \n" +
 " DVD Number: 7 -- Name: Hard Times and Nursery Rhymes -- Type: Music -- Description: Social Distortion -- Price: 10 \n";
        

        String result = storageDVDS.displayAllRecords();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of sortAllRecords method, of class storageDVDS.
     */
    @Test
    public void testSortAllRecords() {
        System.out.println("sortAllRecords");

String expResult = " DVD Number: 4 -- Name: A Weekend In The City -- Type: Music -- "
                + "Description: Bloc Party -- Price: 9 \n" +
" DVD Number: 7 -- Name: Hard Times and Nursery Rhymes -- Type: Music -- "
                + "Description: Social Distortion -- Price: 10 \n" +
" DVD Number: 3 -- Name: Inception -- Type: Film -- Description: dreams sleep "
                + "-- Price: 24 \n" +
" DVD Number: 6 -- Name: Mellon Collie And The Infinite Sadness -- Type: Music "
                + "-- Description: The Smashing Pumpkins -- Price: 10 \n" +
" DVD Number: 2 -- Name: Wild Wild West -- Type: Film -- Description: film set in the wild west -- Price: 19 \n";

        String result = storageDVDS.sortAllRecords();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of searchUsingDescription method, of class storageDVDS.
     */
    @Test
    public void testSearchUsingDescription() {
        System.out.println("searchUsingDescription");

        String searchDesc = "smash";
        String expResult = " DVD Number: 6 -- Name: Mellon Collie And The "
                + "Infinite Sadness -- Type: Music-- Description: The Smashing "
                + "Pumpkins-- Price: 10 \n\n";

        String result = storageDVDS.searchUsingDescription(searchDesc);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of goToPreviousRecord method, of class storageDVDS.
     */
    @Test
    public void testGoToPreviousRecord() {
        System.out.println("goToPreviousRecord");

        int idValue = 2;
        String expResult = " DVD Number: 1 -- Name: Mega Man 9 -- Type: Game -- Description: retro platformer game -- Price: 6 \n";

        String result = storageDVDS.goToPreviousRecord(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of goToNextRecord method, of class storageDVDS.
     */
    @Test
    public void testGoToNextRecord() {
        System.out.println("goToNextRecord");

        int idValue = 1;
        String expResult = " DVD Number: 2 -- Name: Wild Wild West -- Type: Film -- Description: film set in the wild west -- Price: 19 \n";

        String result = storageDVDS.goToNextRecord(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of goToFirstRecord method, of class storageDVDS.
     */
    @Test
    public void testGoToFirstRecord() {
        System.out.println("goToFirstRecord");

        String expResult = " DVD Number: 1 -- Name: Mega Man 9 -- Type: Game -- Description: retro platformer game -- Price: 6 ";
        String result = storageDVDS.goToFirstRecord();

        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of goToLastRecord method, of class storageDVDS.
     */
    @Test
    public void testGoToLastRecord() {
        System.out.println("goToLastRecord");

        String expResult = " DVD Number: 7 -- Name: Hard Times and Nursery Rhymes -- Type: Music -- Description: Social Distortion -- Price: 10 ";
        String result = storageDVDS.goToLastRecord();

        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

 

    /**
     * Test of getDVDName method, of class storageDVDS.
     */
    @Test
    public void testGetDVDName() {
        System.out.println("getDVDName");

        int idValue = 4;
        String expResult = "A Weekend In The City";

        String result = storageDVDS.getDVDName(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDVDType method, of class storageDVDS.
     */
    @Test
    public void testGetDVDType() {
        System.out.println("getDVDType");

        int idValue = 4;
        String expResult = "Music";

        String result = storageDVDS.getDVDType(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDVDDescription method, of class storageDVDS.
     */
    @Test
    public void testGetDVDDescription() {
        System.out.println("getDVDDescription");

        int idValue = 4;
        String expResult = "Bloc Party";

        String result = storageDVDS.getDVDDescription(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDVDPrice method, of class storageDVDS.
     */
    @Test
    public void testGetDVDPrice() {
        System.out.println("getDVDPrice");

        int idValue = 4;
        String expResult = "9";
        String result = storageDVDS.getDVDPrice(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDVDImage method, of class storageDVDS.
     */
    @Test
    public void testGetDVDImage() {
        System.out.println("getDVDImage");
        int idValue = 4;
        String expResult = "a-weekend-in-the-city.jpg";
        String result = storageDVDS.getDVDImage(idValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

  /**
     * Test of deleteRecord method, of class storageDVDS.
     */
    @Test
    public void testDeleteRecord() {
        System.out.println("deleteRecord");

        int numDel = 1;

        storageDVDS.deleteRecord(numDel);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    /**
     * Test of saveAll method, of class storageDVDS.
     */
    @Test
    public void testSaveAll() {
        System.out.println("saveAll");
        
        int numSave = 1;
        String nameSave = "Rock Man 9";
        String typeSave = "Music";
        String descSave = "platform game";
        int priceSave = 6;
        String imageSave = "1239.jpg";

        storageDVDS.saveAll(numSave, nameSave, typeSave, descSave, priceSave, imageSave);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

   

    /**
     * Test of editDVDName method, of class storageDVDS.
     */
    @Test
    public void testEditDVDName() {
        System.out.println("editDVDName");

        String nameUpdate = "Mega Man 9";
        int idValue = 1;

        storageDVDS.editDVDName(nameUpdate, idValue);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of editDVDType method, of class storageDVDS.
     */
    @Test
    public void testEditDVDType() {
        System.out.println("editDVDType");
        
        String typeUpdate = "Game";
        int idValue = 1;

        storageDVDS.editDVDType(typeUpdate, idValue);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of editDVDDescription method, of class storageDVDS.
     */
    @Test
    public void testEditDVDDescription() {
        System.out.println("editDVDDescription");

        String descUpdate = "retro platformer game";
        int idValue = 1;

        storageDVDS.editDVDDescription(descUpdate, idValue);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of editDVDPrice method, of class storageDVDS.
     */
    @Test
    public void testEditDVDPrice() {
        System.out.println("editDVDPrice");
        
        String priceUpdate = "6";
        int idValue = 1;

        storageDVDS.editDVDPrice(priceUpdate, idValue);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of editDVDCover method, of class storageDVDS.
     */
    @Test
    public void testEditDVDCover() {
        System.out.println("editDVDCover");
        
        String coverUpdate = "RockMan-9.jpg";
        int idValue = 1;

        storageDVDS.editDVDCover(coverUpdate, idValue);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of closeDBConnection method, of class storageDVDS.
     */
    @Test
    public void testCloseDBConnection() {
        System.out.println("closeDBConnection");

        storageDVDS.closeDBConnection();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

}