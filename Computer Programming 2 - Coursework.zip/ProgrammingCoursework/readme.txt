 					       Program Instructions




						    Main Menu

The main menu consists of 4 buttons, the button to the far left is the Save and Modify DVD Records which takes you to
another window and allows you to simply Save and Modify the DVD Records saved in the external database the program is 
connected to. The second button to the left is the Display Existing DVD Records button which also opens up another 
window this time it's used for Displaying the different elements of the DVD Records that have been saved or edited.

The third button you clicked on should be familiar to you as it's the Click for Instructions button you may have 
possibly used to open this file with. The last button which is located underneath the others is the Exit button 
which allows you to Exit the Program with ease (since you can't exit after clicking the X button in the right 
hand corner).



					   Save and Modify DVD Records

After clicking on the button saying 'Save and Modify DVD Records' you will be brought here to the Save and Modify DVD
Records section of the program which allows you to input a new record via the various text fields on screen, it also 
allows you to edit a full record that's already saved in the external database but if you just want to edit a certain 
aspect of the saved record there are buttons for editing each seperate part. 

Aside from the features mentioned above, you can also delete whole records from the database with the click of the
delete button.



					   Display Existing DVD Records

After click the button which displays 'Display Existing DVD Records' you be taken to the Display DVD REcords section of
the program. Here you can use the various different ways of viewing the stored record data, it ranges from display all
of the records to searching using the DVD Description as well as sorting the records in alphabetical order by DVD Name
and so on.
 
Please take note that the Sorting and Description Searching of Records restricts the data to only show the Film and Music
types of DVD's.



				 Exiting the Program and other Closing Operations

Exiting the program is simple! There is a little button on the Main Menu of the program which says "Exit" which will
then close the window. However be careful as if you click the Exit button to get rid of the Main Menu with other 
windows open they will close too. You can avoid this by clicking the red X in the top right corner of the Main Menu 
after you have opened another window of the program, this will then close the Main Menu window.

THe Main Menu can be brought back by click the "Back to Main Menu" buttons on each of the other windows, doing this
will cause the Main Menu to appear again and allow you to use the Exit button but not the red X button (until
another window is opened).

}
 